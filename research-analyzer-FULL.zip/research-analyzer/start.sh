#!/bin/bash
# ============================================================
# start.sh — Linux/macOS Startup Script
# ============================================================
# Usage:
#   chmod +x start.sh
#   ./start.sh
# ============================================================

set -e

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║   AI Research Paper Analyzer — Startup       ║${NC}"
echo -e "${CYAN}║   BSc Data Science Major Project             ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════╝${NC}"
echo ""

# ── Check Python ─────────────────────────────────────────────────
echo -e "${YELLOW}[1/5] Checking Python...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}✗ Python 3 not found. Install from https://python.org${NC}"
    exit 1
fi
PYTHON_VER=$(python3 --version 2>&1)
echo -e "${GREEN}✓ $PYTHON_VER${NC}"

# ── Navigate to backend ───────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"

if [ ! -d "$BACKEND_DIR" ]; then
    echo -e "${RED}✗ backend/ directory not found. Run from project root.${NC}"
    exit 1
fi

cd "$BACKEND_DIR"

# ── Virtual environment ───────────────────────────────────────────
echo -e "${YELLOW}[2/5] Setting up virtual environment...${NC}"
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo -e "${GREEN}✓ Created venv/${NC}"
else
    echo -e "${GREEN}✓ venv/ already exists${NC}"
fi

source venv/bin/activate

# ── Install dependencies ──────────────────────────────────────────
echo -e "${YELLOW}[3/5] Installing dependencies...${NC}"
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
echo -e "${GREEN}✓ Dependencies installed${NC}"

# ── Download NLP models ───────────────────────────────────────────
echo -e "${YELLOW}[4/5] Downloading NLP models...${NC}"
python3 -c "import nltk; [nltk.download(p, quiet=True) for p in ['punkt','stopwords','wordnet','vader_lexicon','averaged_perceptron_tagger']]"
python3 -m spacy download en_core_web_sm --quiet 2>/dev/null || true
echo -e "${GREEN}✓ NLP models ready${NC}"

# ── Check .env ────────────────────────────────────────────────────
echo -e "${YELLOW}[5/5] Checking environment...${NC}"
if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        cp .env.example .env
        echo -e "${YELLOW}⚠  Created .env from template. Add your ANTHROPIC_API_KEY for AI features.${NC}"
    fi
else
    echo -e "${GREEN}✓ .env found${NC}"
fi

# ── Start server ──────────────────────────────────────────────────
echo ""
echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo -e "${GREEN}  ✓ Starting backend server on port 5000...${NC}"
echo -e "${GREEN}  → Open frontend/index.html in your browser${NC}"
echo -e "${GREEN}  → API: http://localhost:5000${NC}"
echo -e "${GREEN}  → Press Ctrl+C to stop${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo ""

python3 app.py
