/**
 * ============================================================
 * voice_summary.js — Voice Summary Module
 * ============================================================
 * Provides Text-to-Speech functionality for paper summaries.
 * Uses the Web Speech API (built into modern browsers).
 *
 * Features:
 *  - Read abstract / summary aloud
 *  - Play / Pause / Stop controls
 *  - Adjustable speed and pitch
 *  - Voice selection (multiple languages)
 *  - Highlight text as it is spoken
 *  - Visual speaking indicator
 *
 * Usage:
 *   import { VoiceSummary } from './voice_summary.js'
 *   const vs = new VoiceSummary();
 *   vs.speak("Your summary text here...");
 * ============================================================
 */

export class VoiceSummary {
  constructor(options = {}) {
    this.synth       = window.speechSynthesis;
    this.utterance   = null;
    this.isSpeaking  = false;
    this.isPaused    = false;
    this.voices      = [];

    // Default settings
    this.rate   = options.rate   ?? 0.9;    // 0.1 – 2.0
    this.pitch  = options.pitch  ?? 1.0;    // 0.0 – 2.0
    this.volume = options.volume ?? 1.0;    // 0.0 – 1.0
    this.lang   = options.lang   ?? 'en-US';

    // Callbacks
    this.onStart   = options.onStart   ?? (() => {});
    this.onEnd     = options.onEnd     ?? (() => {});
    this.onPause   = options.onPause   ?? (() => {});
    this.onResume  = options.onResume  ?? (() => {});
    this.onWord    = options.onWord    ?? (() => {});  // (charIndex, word)
    this.onError   = options.onError   ?? ((e) => console.error('[Voice]', e));

    this._loadVoices();
  }

  // ── Voice Loading ────────────────────────────────────────────

  _loadVoices() {
    const setVoices = () => {
      this.voices = this.synth.getVoices();
    };
    setVoices();
    if (typeof speechSynthesis !== 'undefined' && speechSynthesis.onvoiceschanged !== undefined) {
      speechSynthesis.onvoiceschanged = setVoices;
    }
  }

  getVoices() {
    return this.synth.getVoices();
  }

  getEnglishVoices() {
    return this.voices.filter(v => v.lang.startsWith('en'));
  }

  // ── Core Controls ────────────────────────────────────────────

  /**
   * Speak a text string aloud.
   * @param {string} text - Text to read
   * @param {string} [voiceName] - Optional voice name from getVoices()
   */
  speak(text, voiceName = null) {
    if (!this.synth) {
      this.onError('Speech synthesis not supported in this browser.');
      return;
    }

    // Stop any current speech
    this.stop();

    if (!text || text.trim().length === 0) {
      this.onError('No text provided to speak.');
      return;
    }

    // Preprocess: remove special chars, URLs, citations
    const cleaned = this._preprocessText(text);

    this.utterance = new SpeechSynthesisUtterance(cleaned);
    this.utterance.rate   = this.rate;
    this.utterance.pitch  = this.pitch;
    this.utterance.volume = this.volume;
    this.utterance.lang   = this.lang;

    // Set voice
    if (voiceName) {
      const voice = this.voices.find(v => v.name === voiceName);
      if (voice) this.utterance.voice = voice;
    } else {
      // Pick best English voice
      const preferred = this.voices.find(v =>
        v.lang === 'en-US' && v.localService
      ) || this.voices.find(v => v.lang.startsWith('en'));
      if (preferred) this.utterance.voice = preferred;
    }

    // Events
    this.utterance.onstart = () => {
      this.isSpeaking = true;
      this.isPaused   = false;
      this.onStart();
    };

    this.utterance.onend = () => {
      this.isSpeaking = false;
      this.isPaused   = false;
      this.onEnd();
    };

    this.utterance.onpause = () => {
      this.isPaused = true;
      this.onPause();
    };

    this.utterance.onresume = () => {
      this.isPaused = false;
      this.onResume();
    };

    this.utterance.onboundary = (event) => {
      if (event.name === 'word') {
        const word = cleaned.substr(event.charIndex, event.charLength || 5);
        this.onWord(event.charIndex, word);
      }
    };

    this.utterance.onerror = (event) => {
      this.isSpeaking = false;
      this.onError(event.error);
    };

    this.synth.speak(this.utterance);
  }

  pause() {
    if (this.isSpeaking && !this.isPaused) {
      this.synth.pause();
    }
  }

  resume() {
    if (this.isPaused) {
      this.synth.resume();
    }
  }

  stop() {
    this.synth.cancel();
    this.isSpeaking = false;
    this.isPaused   = false;
  }

  toggle() {
    if (!this.isSpeaking) return;
    this.isPaused ? this.resume() : this.pause();
  }

  // ── Settings ─────────────────────────────────────────────────

  setRate(rate)     { this.rate   = Math.max(0.1, Math.min(2.0, rate));   }
  setPitch(pitch)   { this.pitch  = Math.max(0.0, Math.min(2.0, pitch));  }
  setVolume(volume) { this.volume = Math.max(0.0, Math.min(1.0, volume)); }
  setLang(lang)     { this.lang   = lang; }

  // ── Text Preprocessing ───────────────────────────────────────

  _preprocessText(text) {
    return text
      .replace(/https?:\/\/\S+/g, '')                   // Remove URLs
      .replace(/\[\d+(?:,\s*\d+)*\]/g, '')              // Remove citation markers [1,2]
      .replace(/\((?:[A-Z][a-z]+\s+et\s+al\.,?\s+)?\d{4}\)/g, '') // Remove (Author 2023)
      .replace(/[<>{}[\]]/g, '')                         // Remove brackets
      .replace(/\s{2,}/g, ' ')                           // Collapse spaces
      .replace(/[*_~`#]/g, '')                           // Remove markdown
      .trim();
  }

  // ── Status ───────────────────────────────────────────────────

  get status() {
    if (this.isSpeaking && !this.isPaused) return 'speaking';
    if (this.isPaused) return 'paused';
    return 'idle';
  }

  get supported() {
    return 'speechSynthesis' in window;
  }
}


// ── Voice Player UI Component ─────────────────────────────────────
/**
 * VoicePlayerUI — Renders a floating voice controls widget
 * and binds it to a VoiceSummary instance.
 *
 * Usage:
 *   const ui = new VoicePlayerUI(document.getElementById('voice-widget'), text);
 */
export class VoicePlayerUI {
  constructor(container, text = '') {
    this.container = container;
    this.text = text;
    this.vs = new VoiceSummary({
      onStart:  () => this._updateState('speaking'),
      onEnd:    () => this._updateState('idle'),
      onPause:  () => this._updateState('paused'),
      onResume: () => this._updateState('speaking'),
    });
    this._render();
  }

  _render() {
    this.container.innerHTML = `
      <div class="voice-player" style="
        display:flex;align-items:center;gap:12px;
        padding:12px 18px;
        background:rgba(13,18,36,0.85);
        border:1px solid rgba(99,102,241,0.3);
        border-radius:12px;
        backdrop-filter:blur(12px);
        max-width:420px;
      ">
        <button id="vp-play" title="Play summary" style="
          width:40px;height:40px;border-radius:50%;border:none;
          background:linear-gradient(135deg,#6366f1,#8b5cf6);
          color:#fff;font-size:16px;cursor:pointer;
          display:flex;align-items:center;justify-content:center;
          transition:all 0.2s;
        ">▶</button>
        <button id="vp-stop" title="Stop" style="
          width:32px;height:32px;border-radius:50%;border:1px solid rgba(99,102,241,0.4);
          background:transparent;color:#94a3b8;font-size:12px;cursor:pointer;
          display:flex;align-items:center;justify-content:center;
        ">■</button>
        <div style="flex:1;">
          <div id="vp-label" style="font-size:0.8rem;color:#94a3b8;font-family:Space Grotesk,sans-serif;">
            🔊 Voice Summary
          </div>
          <div id="vp-status" style="font-size:0.72rem;color:#6366f1;font-family:JetBrains Mono,monospace;margin-top:2px;">
            Ready
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:4px;">
          <label style="font-size:0.68rem;color:#4a5568;">Speed</label>
          <input id="vp-rate" type="range" min="0.5" max="1.8" step="0.1" value="0.9"
            style="width:70px;accent-color:#6366f1;" />
        </div>
      </div>`;

    const playBtn = this.container.querySelector('#vp-play');
    const stopBtn = this.container.querySelector('#vp-stop');
    const rateSlider = this.container.querySelector('#vp-rate');

    playBtn.addEventListener('click', () => {
      if (this.vs.status === 'idle') {
        this.vs.speak(this.text);
      } else {
        this.vs.toggle();
      }
    });

    stopBtn.addEventListener('click', () => this.vs.stop());

    rateSlider.addEventListener('input', (e) => {
      this.vs.setRate(parseFloat(e.target.value));
    });
  }

  setText(text) {
    this.text = text;
  }

  _updateState(state) {
    const playBtn = this.container.querySelector('#vp-play');
    const statusEl = this.container.querySelector('#vp-status');
    if (state === 'speaking') {
      playBtn.textContent = '⏸';
      statusEl.textContent = '● Speaking...';
      statusEl.style.color = '#10b981';
    } else if (state === 'paused') {
      playBtn.textContent = '▶';
      statusEl.textContent = '⏸ Paused';
      statusEl.style.color = '#f59e0b';
    } else {
      playBtn.textContent = '▶';
      statusEl.textContent = 'Ready';
      statusEl.style.color = '#6366f1';
    }
  }
}
