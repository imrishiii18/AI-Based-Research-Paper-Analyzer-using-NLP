# 🔬 AI Research Paper Analyzer
### BSc Data Science Major Project — NLP Intelligence Platform

> An end-to-end web application that analyzes research papers using NLP & AI, generating 18+ structured insights including summaries, keywords, citations, sentiment, gaps, future scope, and more.

---

## 📸 Features

| Feature | Description |
|--------|-------------|
| 📄 **Smart Summary** | TextRank + AI-powered abstract & full summary |
| 🔑 **Keyword Extraction** | TF-IDF with frequency charts |
| 📋 **Citation Analysis** | APA / IEEE / MLA detection & counter |
| 🔭 **Research Gap Finder** | NLP-based limitation detection |
| 🔮 **Future Scope** | AI predicts future research directions |
| 📊 **Topic Detection** | LDA-based topic modeling |
| ⚙️ **Methodology Extraction** | Algorithm & dataset detection |
| 🎭 **Sentiment Analysis** | Writing tone (Analytical / Positive / Neutral) |
| 📈 **Complexity Scoring** | Flesch readability + vocabulary density |
| 💬 **Chat with Paper** | Ask questions via QA over the paper |
| 📥 **PDF Report** | Downloadable full analysis report |
| 🌗 **Dark / Light Mode** | Beautiful animated UI with theme toggle |

---

## 🗂️ Project Structure

```
research-analyzer/
│
├── frontend/
│   └── index.html              ← Complete single-page frontend (HTML/CSS/JS)
│
├── backend/
│   ├── app.py                  ← Flask API server (main entry point)
│   ├── nlp_processor.py        ← All NLP analysis logic
│   ├── report_generator.py     ← PDF report generation
│   ├── requirements.txt        ← Python dependencies
│   │
│   ├── uploads/                ← Temp file uploads (auto-created)
│   ├── reports/                ← Generated PDF reports (auto-created)
│   ├── templates/              ← Flask HTML templates (optional)
│   ├── static/                 ← Static assets
│   └── models/                 ← Local ML models (optional)
│
└── README.md
```

---

## ⚙️ Setup & Installation

### Prerequisites
- Python 3.9+ 
- pip
- Node.js (optional, not required — frontend is pure HTML)
- Anthropic API key (optional — enables AI-powered summaries; falls back to rule-based)

---

### Step 1 — Clone / Extract the Project

```bash
cd research-analyzer/backend
```

### Step 2 — Install Python Dependencies

```bash
pip install -r requirements.txt
```

**Minimal install** (no AI, no OCR):
```bash
pip install flask flask-cors nltk spacy pdfplumber python-docx reportlab
```

### Step 3 — Download NLP Models

```bash
# Download spaCy English model
python -m spacy download en_core_web_sm

# NLTK data (auto-downloaded on first run, or manually):
python -c "import nltk; nltk.download('all')"
```

### Step 4 — Set API Key (Optional but Recommended)

The Anthropic API key enables high-quality AI summarization. Without it, the system uses rule-based NLP (still functional).

```bash
# Linux / macOS
export ANTHROPIC_API_KEY=your_api_key_here

# Windows CMD
set ANTHROPIC_API_KEY=your_api_key_here

# Windows PowerShell
$env:ANTHROPIC_API_KEY="your_api_key_here"
```

Or create a `.env` file in `backend/`:
```
ANTHROPIC_API_KEY=your_api_key_here
```

### Step 5 — Run the Backend

```bash
cd backend
python app.py
```

You should see:
```
========================================================
  AI Research Paper Analyzer — Backend Server
  URL: http://localhost:5000
  Health: http://localhost:5000/health
========================================================
```

### Step 6 — Open the Frontend

Simply open `frontend/index.html` in any browser:
```bash
# macOS
open frontend/index.html

# Windows
start frontend/index.html

# Linux
xdg-open frontend/index.html
```

Or serve it with Python's built-in server:
```bash
cd frontend
python -m http.server 8080
# Then visit: http://localhost:8080
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/health` | Server health check |
| `POST` | `/api/analyze` | Analyze uploaded file or pasted text |
| `POST` | `/api/chat` | Chat with paper (QA) |
| `POST` | `/api/report` | Download PDF report |

### `/api/analyze` — File Upload
```bash
curl -X POST http://localhost:5000/api/analyze \
  -F "file=@paper.pdf"
```

### `/api/analyze` — Text Input
```bash
curl -X POST http://localhost:5000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{"text": "Your research paper text here..."}'
```

### `/api/chat` — Ask Questions
```bash
curl -X POST http://localhost:5000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"question": "What methodology was used?", "paper_text": "..."}'
```

---

## 📊 Analysis Output — JSON Structure

```json
{
  "title": "Paper title",
  "authors": ["Author 1", "Author 2"],
  "word_count": 8432,
  "sentence_count": 412,
  "citation_count": 47,
  "citation_style": "IEEE",
  "complexity_score": 8.2,
  "complexity_label": "Hard",
  "readability_score": 58,
  "novelty_score": 7,
  "sentiment": "Analytical",
  "sentiment_scores": {"analytical": 72, "positive": 20, "neutral": 8},
  "abstract_summary": "...",
  "full_summary": "...",
  "key_findings": ["Finding 1", "..."],
  "problem_statement": "...",
  "methodology": "...",
  "results_analysis": "...",
  "conclusion": "...",
  "sections": [{"title": "Introduction", "summary": "...", "word_count": 600}],
  "keywords": [{"word": "transformer", "score": 0.045, "freq": 89}],
  "topics": ["NLP", "Deep Learning"],
  "algorithms": ["BERT", "Transformer", "Adam"],
  "datasets": ["GLUE", "SQuAD"],
  "citations": ["[1] Author et al. (2023)..."],
  "research_gaps": ["Gap 1", "Gap 2"],
  "future_scope": ["Future direction 1"],
  "recommendations": ["Recommendation 1"]
}
```

---

## 🧪 Tech Stack

### Frontend
| Technology | Purpose |
|-----------|---------|
| HTML5 / CSS3 / Vanilla JS | UI framework |
| Chart.js 4 | Dynamic charts |
| Canvas API | Neural particle animation |
| CSS Glass morphism | Card designs |
| Playfair Display + Space Grotesk | Typography |

### Backend
| Technology | Purpose |
|-----------|---------|
| Python 3.11 | Backend language |
| Flask 3.0 | REST API server |
| NLTK | Tokenization, lemmatization, VADER sentiment |
| spaCy | NER, advanced NLP |
| pdfplumber | PDF text extraction |
| python-docx | DOCX text extraction |
| pytesseract | OCR for scanned PDFs |
| Anthropic Claude | AI summarization & QA |
| reportlab | PDF report generation |
| scikit-learn | TF-IDF, ML utilities |

---

## 🎨 UI Design

- **Theme**: Dark-first with Light mode toggle
- **Color Palette**: Indigo (#6366f1) + Violet (#8b5cf6) + Cyan (#22d3ee)
- **Typography**: Playfair Display (headings) + Space Grotesk (body) + JetBrains Mono (code)
- **Effects**: Neural network particle canvas, glassmorphism cards, gradient backgrounds
- **Layout**: Responsive grid, sidebar dashboard, tabbed results

---

## 🚀 Quick Demo (No Backend)

The frontend includes a full **demo mode** with sample data — it automatically activates if the backend is not running. Open `frontend/index.html` in a browser, paste any text, and click Analyze. The demo shows all UI features with realistic sample data.

---

## 🔧 Troubleshooting

### "Module not found: spacy"
```bash
pip install spacy && python -m spacy download en_core_web_sm
```

### "Module not found: pdfplumber"
```bash
pip install pdfplumber
```

### "Backend not reachable"
The frontend automatically falls back to demo data if the Flask backend isn't running. Start the backend with `python app.py`.

### "CORS error"
Flask-CORS is configured to allow all origins. Make sure `flask-cors` is installed:
```bash
pip install flask-cors
```

### PDF OCR not working
Install Tesseract OCR system package:
```bash
# Ubuntu/Debian
sudo apt-get install tesseract-ocr

# macOS
brew install tesseract
```

---

## 📝 Academic Information

- **Project Title**: AI-Based Research Paper Summarization and Insight Extraction System
- **Domain**: Natural Language Processing, Information Extraction
- **Techniques**: TF-IDF, TextRank, NER, VADER, Flesch Readability, Transformer-based AI
- **Tools**: Python, Flask, NLTK, spaCy, Anthropic Claude, Chart.js
- **Output**: Web dashboard + downloadable PDF report

---

## 📄 License

Built for educational purposes as a BSc Data Science Major Project.

---

*Made with 🧠 NLP · Flask · Transformers · Chart.js*
