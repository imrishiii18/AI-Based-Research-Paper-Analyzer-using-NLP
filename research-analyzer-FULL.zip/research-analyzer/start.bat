@echo off
:: ============================================================
:: start.bat — Windows Startup Script
:: ============================================================
:: Double-click this file or run from CMD:
::   start.bat
:: ============================================================

title AI Research Paper Analyzer

echo.
echo =====================================================
echo   AI Research Paper Analyzer -- Startup
echo   BSc Data Science Major Project
echo =====================================================
echo.

:: Check Python
echo [1/5] Checking Python...
python --version > nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found. Download from https://python.org
    pause
    exit /b 1
)
python --version
echo.

:: Navigate to backend
set SCRIPT_DIR=%~dp0
set BACKEND_DIR=%SCRIPT_DIR%backend

if not exist "%BACKEND_DIR%" (
    echo [ERROR] backend\ folder not found.
    pause
    exit /b 1
)

cd /d "%BACKEND_DIR%"

:: Virtual environment
echo [2/5] Setting up virtual environment...
if not exist "venv" (
    python -m venv venv
    echo Created venv\
) else (
    echo venv\ already exists
)

call venv\Scripts\activate.bat

:: Install dependencies
echo.
echo [3/5] Installing dependencies...
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
echo Dependencies installed.

:: Download NLP models
echo.
echo [4/5] Downloading NLP models...
python -c "import nltk; [nltk.download(p, quiet=True) for p in ['punkt','stopwords','wordnet','vader_lexicon','averaged_perceptron_tagger']]"
python -m spacy download en_core_web_sm 2>nul
echo NLP models ready.

:: Check .env
echo.
echo [5/5] Checking environment...
if not exist ".env" (
    if exist ".env.example" (
        copy .env.example .env > nul
        echo Created .env from template.
        echo Add your ANTHROPIC_API_KEY in .env for AI features.
    )
) else (
    echo .env found.
)

:: Start server
echo.
echo =====================================================
echo   Starting backend server on http://localhost:5000
echo   Open frontend\index.html in your browser
echo   Press Ctrl+C to stop the server
echo =====================================================
echo.

python app.py

pause
