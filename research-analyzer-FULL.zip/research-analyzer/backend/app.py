"""
========================================================
app.py — Flask Backend (Full Version with All Modules)
========================================================
BSc Data Science Major Project
All new modules integrated:
  - config.py           → centralized settings
  - utils.py            → helper functions
  - wordcloud_gen.py    → word cloud generation
  - compare_papers.py   → paper comparison
  - diagram_analyzer.py → figure analysis
  - multi_language.py   → multi-language support

API Endpoints:
  GET  /health
  POST /api/analyze
  POST /api/chat
  POST /api/report
  POST /api/wordcloud
  POST /api/compare
  POST /api/translate
  GET  /api/languages
  POST /api/diagrams

Run:  python app.py
========================================================
"""

import os
import json
import traceback
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from werkzeug.utils import secure_filename

# ── Local imports ─────────────────────────────────────────────────
from config import FlaskConfig, NLPConfig
from nlp_processor import ResearchPaperAnalyzer
from report_generator import generate_pdf_report
from wordcloud_gen import generate_wordcloud, generate_keyword_barchart
from compare_papers import PaperComparator
from diagram_analyzer import DiagramAnalyzer
from multi_language import MultiLanguageHandler
from utils import (
    allowed_file, clean_text, truncate_text,
    success_response, error_response, sanitize_output,
    logger, timer
)

# ── Flask App ─────────────────────────────────────────────────────
app = Flask(__name__)
CORS(app)

app.config['MAX_CONTENT_LENGTH'] = FlaskConfig.MAX_CONTENT_LENGTH
app.config['UPLOAD_FOLDER']      = FlaskConfig.UPLOAD_FOLDER

os.makedirs(FlaskConfig.UPLOAD_FOLDER, exist_ok=True)
os.makedirs(FlaskConfig.REPORT_FOLDER, exist_ok=True)

# ── Module instances ──────────────────────────────────────────────
analyzer     = ResearchPaperAnalyzer()
comparator   = PaperComparator()
diagram_ai   = DiagramAnalyzer()
lang_handler = MultiLanguageHandler()


# ══════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════

def extract_text_from_file(filepath: str, ext: str) -> str:
    """Extract raw text from uploaded file."""
    text = ""

    if ext == 'txt':
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            text = f.read()

    elif ext == 'pdf':
        try:
            import pdfplumber
            with pdfplumber.open(filepath) as pdf:
                pages = [p.extract_text() or '' for p in pdf.pages]
                text = '\n\n'.join(pages)
        except ImportError:
            text = "[pdfplumber not installed — pip install pdfplumber]"
        except Exception as e:
            try:
                import fitz
                import pytesseract
                from PIL import Image
                import io
                doc = fitz.open(filepath)
                pages = []
                for page in doc:
                    pix = page.get_pixmap(dpi=200)
                    img = Image.open(io.BytesIO(pix.tobytes("png")))
                    pages.append(pytesseract.image_to_string(img))
                text = '\n\n'.join(pages)
            except Exception:
                text = f"[PDF extraction failed: {str(e)}]"

    elif ext == 'docx':
        try:
            from docx import Document
            doc = Document(filepath)
            text = '\n\n'.join(p.text for p in doc.paragraphs if p.text.strip())
        except ImportError:
            text = "[python-docx not installed — pip install python-docx]"
        except Exception as e:
            text = f"[DOCX extraction failed: {str(e)}]"

    return clean_text(text.strip())


# ══════════════════════════════════════════════════════════════════
# ROUTES
# ══════════════════════════════════════════════════════════════════

@app.route('/health', methods=['GET'])
def health():
    """Health check & module status."""
    return jsonify({
        "status":  "ok",
        "message": "AI Research Paper Analyzer API",
        "version": "2.0.0",
        "modules": {
            "nlp_processor":    True,
            "wordcloud":        True,
            "compare_papers":   True,
            "diagram_analyzer": True,
            "multi_language":   True,
            "report_generator": True,
        }
    }), 200


# ── ANALYZE ───────────────────────────────────────────────────────
@app.route('/api/analyze', methods=['POST'])
@timer
def analyze():
    """
    Main endpoint: analyze paper from file upload or pasted text.
    Query param: ?lang=es  (optional — translate outputs)
    """
    text = ""
    filename = "pasted_text.txt"
    filepath = None
    figures_from_file = []

    # -- Handle file upload
    if 'file' in request.files:
        file = request.files['file']
        if file.filename == '':
            return jsonify(error_response("No file selected")), 400
        if not allowed_file(file.filename, FlaskConfig.ALLOWED_EXTENSIONS):
            return jsonify(error_response("Unsupported type. Use PDF, DOCX, or TXT.")), 400

        filename = secure_filename(file.filename)
        filepath = os.path.join(FlaskConfig.UPLOAD_FOLDER, filename)
        file.save(filepath)
        ext = filename.rsplit('.', 1)[1].lower()
        text = extract_text_from_file(filepath, ext)

        # Diagram extraction for PDFs
        if ext == 'pdf':
            try:
                figures_from_file = diagram_ai.analyze_pdf(filepath)
            except Exception as e:
                logger.warning(f"Diagram analysis skipped: {e}")

        try:
            os.remove(filepath)
        except Exception:
            pass

    # -- Handle raw text
    elif request.is_json:
        data = request.get_json()
        text = (data or {}).get('text', '').strip()
        if not text:
            return jsonify(error_response("No text provided")), 400
    else:
        return jsonify(error_response("Provide file or JSON text body")), 400

    text = truncate_text(text, NLPConfig.MAX_TEXT_LENGTH)

    if len(text) < NLPConfig.MIN_TEXT_LENGTH:
        return jsonify(error_response(
            f"Text too short (need ≥ {NLPConfig.MIN_TEXT_LENGTH} chars)"
        )), 400

    target_lang = request.args.get('lang', 'en')

    try:
        result = analyzer.analyze(text, filename)

        # Merge file-level figures
        if figures_from_file:
            result['figures'] = figures_from_file + result.get('figures', [])

        # Language detection
        result['detected_language'] = lang_handler.detect_language(text)

        # Optional translation
        if target_lang != 'en':
            result = lang_handler.translate_analysis_output(result, target_lang)

        return jsonify(sanitize_output(result)), 200

    except Exception as e:
        traceback.print_exc()
        logger.error(f"Analysis failed: {e}")
        return jsonify(error_response(f"Analysis failed: {str(e)}", 500)), 500


# ── CHAT ──────────────────────────────────────────────────────────
@app.route('/api/chat', methods=['POST'])
def chat():
    """Answer a question about the paper (QA)."""
    data = request.get_json() or {}
    question   = data.get('question', '').strip()
    paper_text = data.get('paper_text', '').strip()

    if not question:
        return jsonify(error_response("No question provided")), 400

    try:
        answer = analyzer.chat_with_paper(question, paper_text)
        return jsonify({"answer": answer}), 200
    except Exception as e:
        traceback.print_exc()
        return jsonify({"answer": f"Could not answer: {str(e)}"}), 500


# ── WORD CLOUD ────────────────────────────────────────────────────
@app.route('/api/wordcloud', methods=['POST'])
def wordcloud():
    """Generate word cloud image. Returns base64 PNG."""
    data     = request.get_json() or {}
    text     = data.get('text', '')
    keywords = data.get('keywords', [])
    theme    = data.get('theme', 'indigo')

    image_b64    = generate_wordcloud(text=text, keywords=keywords, theme=theme)
    barchart_b64 = generate_keyword_barchart(keywords, theme) if keywords else None

    if not image_b64:
        return jsonify(error_response("Could not generate word cloud")), 500

    return jsonify({
        "wordcloud": image_b64,
        "barchart":  barchart_b64,
    }), 200


# ── COMPARE ───────────────────────────────────────────────────────
@app.route('/api/compare', methods=['POST'])
def compare():
    """Compare two analyzed papers side by side."""
    data   = request.get_json() or {}
    paper1 = data.get('paper1')
    paper2 = data.get('paper2')

    if not paper1 or not paper2:
        return jsonify(error_response("Provide both paper1 and paper2 JSON")), 400

    try:
        result = comparator.compare(paper1, paper2)
        return jsonify(result), 200
    except Exception as e:
        traceback.print_exc()
        return jsonify(error_response(f"Comparison failed: {str(e)}", 500)), 500


# ── TRANSLATE ─────────────────────────────────────────────────────
@app.route('/api/translate', methods=['POST'])
def translate():
    """Translate text or full analysis JSON to another language."""
    data        = request.get_json() or {}
    text        = data.get('text', '')
    analysis    = data.get('analysis')
    target_lang = data.get('target_lang', 'en')

    if not text and not analysis:
        return jsonify(error_response("Provide text or analysis JSON")), 400

    try:
        if analysis:
            result = lang_handler.translate_analysis_output(analysis, target_lang)
            return jsonify(result), 200
        else:
            detected   = lang_handler.detect_language(text)
            translated = lang_handler.translate(text, target_lang)
            return jsonify({
                "translated":    translated,
                "detected_lang": detected,
                "target_lang":   target_lang,
            }), 200
    except Exception as e:
        traceback.print_exc()
        return jsonify(error_response(f"Translation failed: {str(e)}", 500)), 500


# ── LANGUAGES ─────────────────────────────────────────────────────
@app.route('/api/languages', methods=['GET'])
def languages():
    """List all supported translation languages."""
    return jsonify({"languages": lang_handler.list_supported_languages()}), 200


# ── DIAGRAMS ──────────────────────────────────────────────────────
@app.route('/api/diagrams', methods=['POST'])
def diagrams():
    """Extract and describe figures/tables from paper text."""
    data = request.get_json() or {}
    text = data.get('text', '')

    if not text:
        return jsonify(error_response("No text provided")), 400

    try:
        figures = diagram_ai.analyze_text(text)
        return jsonify({"figures": figures, "count": len(figures)}), 200
    except Exception as e:
        return jsonify(error_response(f"Diagram analysis failed: {str(e)}", 500)), 500


# ── REPORT ────────────────────────────────────────────────────────
@app.route('/api/report', methods=['POST'])
def download_report():
    """Generate and return downloadable PDF report."""
    data = request.get_json()
    if not data:
        return jsonify(error_response("No analysis data provided")), 400

    try:
        report_path = generate_pdf_report(data)
        return send_file(
            report_path,
            as_attachment=True,
            download_name='research_analysis_report.pdf',
            mimetype='application/pdf'
        )
    except Exception as e:
        traceback.print_exc()
        return jsonify(error_response(f"Report failed: {str(e)}", 500)), 500


# ── Entry Point ───────────────────────────────────────────────────
if __name__ == '__main__':
    print("=" * 58)
    print("  AI Research Paper Analyzer — Backend v2.0")
    print(f"  http://localhost:{FlaskConfig.PORT}")
    print()
    print("  POST /api/analyze     → Full paper analysis")
    print("  POST /api/chat        → Chat with paper (QA)")
    print("  POST /api/wordcloud   → Word cloud image (base64)")
    print("  POST /api/compare     → Compare two papers")
    print("  POST /api/translate   → Multi-language translation")
    print("  POST /api/report      → Download PDF report")
    print("  POST /api/diagrams    → Figure/diagram extraction")
    print("  GET  /api/languages   → Supported languages list")
    print("  GET  /health          → Server health check")
    print("=" * 58)
    app.run(
        debug=FlaskConfig.DEBUG,
        host=FlaskConfig.HOST,
        port=FlaskConfig.PORT
    )
