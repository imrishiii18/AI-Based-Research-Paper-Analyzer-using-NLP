"""
========================================================
NLP Processor — Core Analysis Engine
========================================================
Handles all NLP operations:
  - Text preprocessing (tokenization, stopwords, lemmatization)
  - Keyword extraction (TF-IDF + RAKE)
  - Summarization (TextRank + AI)
  - Sentiment & complexity analysis
  - Citation extraction & style detection
  - Research gap & future scope detection
  - AI-powered QA (Chat with paper)
  - Named Entity Recognition
  - Topic modelling
========================================================
"""

import re
import os
import math
import string
import json
from collections import Counter
from typing import Any

# ── NLTK ──────────────────────────────────────────────────────────
try:
    import nltk
    # Download required NLTK data (runs once)
    for pkg in ['punkt', 'stopwords', 'wordnet', 'averaged_perceptron_tagger', 'vader_lexicon', 'punkt_tab']:
        try:
            nltk.download(pkg, quiet=True)
        except Exception:
            pass
    from nltk.tokenize import sent_tokenize, word_tokenize
    from nltk.corpus import stopwords
    from nltk.stem import WordNetLemmatizer
    from nltk.sentiment import SentimentIntensityAnalyzer
    NLTK_OK = True
except ImportError:
    NLTK_OK = False
    print("[WARN] nltk not installed. Run: pip install nltk")

# ── spaCy ─────────────────────────────────────────────────────────
try:
    import spacy
    try:
        nlp_spacy = spacy.load("en_core_web_sm")
    except OSError:
        os.system("python -m spacy download en_core_web_sm")
        try:
            nlp_spacy = spacy.load("en_core_web_sm")
        except Exception:
            nlp_spacy = None
    SPACY_OK = nlp_spacy is not None
except ImportError:
    SPACY_OK = False
    nlp_spacy = None
    print("[WARN] spacy not installed. Run: pip install spacy && python -m spacy download en_core_web_sm")

# ── Anthropic (AI Analysis) ───────────────────────────────────────
try:
    import anthropic
    ANTHROPIC_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
    anthropic_client = anthropic.Anthropic(api_key=ANTHROPIC_KEY) if ANTHROPIC_KEY else None
    ANTHROPIC_OK = anthropic_client is not None
except ImportError:
    ANTHROPIC_OK = False
    anthropic_client = None
    print("[WARN] anthropic not installed. Run: pip install anthropic")


# ══════════════════════════════════════════════════════════════════
class ResearchPaperAnalyzer:
    """
    Main analyzer class. Call .analyze(text) to get full analysis.
    """

    def __init__(self):
        if NLTK_OK:
            self.stop_words = set(stopwords.words('english'))
            self.lemmatizer = WordNetLemmatizer()
            self.sia = SentimentIntensityAnalyzer()
        else:
            self.stop_words = set()
            self.lemmatizer = None
            self.sia = None

    # ── Public API ────────────────────────────────────────────────

    def analyze(self, text: str, filename: str = "paper.txt") -> dict:
        """
        Full pipeline analysis of a research paper text.
        Returns structured JSON with all analysis outputs.
        """
        print(f"[Analyzer] Starting analysis on {len(text)} chars")

        # Basic stats
        sentences = self._sent_tokenize(text)
        words = self._word_tokenize(text)
        clean_words = self._clean_tokens(words)
        word_freq = Counter(clean_words)

        # Core NLP outputs
        keywords = self._extract_keywords(text, word_freq)
        title = self._detect_title(text)
        authors = self._detect_authors(text)
        sections = self._detect_sections(text, sentences)
        citations = self._extract_citations(text)
        citation_style = self._detect_citation_style(text)
        entities = self._extract_entities(text)

        # Scores
        complexity_score, complexity_label = self._complexity_score(text, words, clean_words)
        readability = self._readability_score(text, sentences, words)
        sentiment_label, sentiment_scores = self._sentiment_analysis(text)
        novelty_score = self._novelty_score(text, keywords)

        # AI-powered outputs (uses Anthropic API or rule-based fallback)
        ai_results = self._ai_analysis(text, title, sections)

        result = {
            # Header
            "title":            title,
            "authors":          authors,
            "filename":         filename,
            "word_count":       len(words),
            "sentence_count":   len(sentences),
            "citation_count":   len(citations),
            "citation_style":   citation_style,
            "self_citations":   self._count_self_citations(citations, authors),

            # Scores
            "complexity_score":      complexity_score,
            "complexity_label":      complexity_label,
            "complexity_breakdown":  self._complexity_breakdown(text, words, clean_words),
            "readability_score":     readability,
            "novelty_score":         novelty_score,
            "sentiment":             sentiment_label,
            "sentiment_scores":      sentiment_scores,
            "citation_density":      min(100, int(len(citations) / max(len(words) / 1000, 1) * 10)),

            # Summaries (from AI or rule-based)
            "abstract_summary":   ai_results.get("abstract_summary", ""),
            "full_summary":       ai_results.get("full_summary", ""),
            "key_findings":       ai_results.get("key_findings", []),
            "problem_statement":  ai_results.get("problem_statement", ""),
            "methodology":        ai_results.get("methodology", ""),
            "results_analysis":   ai_results.get("results_analysis", ""),
            "conclusion":         ai_results.get("conclusion", ""),

            # Structured extraction
            "sections":      sections,
            "keywords":      keywords,
            "topics":        self._detect_topics(clean_words, keywords),
            "algorithms":    self._detect_algorithms(text),
            "datasets":      self._detect_datasets(text),
            "entities":      entities,
            "citations":     citations,
            "figures":       self._detect_figures(text),

            # Insights
            "research_gaps":    ai_results.get("research_gaps", []),
            "future_scope":     ai_results.get("future_scope", []),
            "recommendations":  ai_results.get("recommendations", []),

            # Raw text for chat
            "raw_text": text[:12000],  # Truncate for JSON size
        }

        print(f"[Analyzer] Analysis complete — {len(result)} fields")
        return result

    def chat_with_paper(self, question: str, paper_text: str) -> str:
        """Answer a question about the paper using AI or pattern matching."""
        if ANTHROPIC_OK:
            return self._ai_chat(question, paper_text)
        return self._rule_based_chat(question, paper_text)

    # ── Preprocessing ─────────────────────────────────────────────

    def _sent_tokenize(self, text: str) -> list:
        if NLTK_OK:
            return sent_tokenize(text)
        return [s.strip() for s in re.split(r'(?<=[.!?])\s+', text) if s.strip()]

    def _word_tokenize(self, text: str) -> list:
        if NLTK_OK:
            return word_tokenize(text)
        return re.findall(r'\b[a-zA-Z]+\b', text)

    def _clean_tokens(self, tokens: list) -> list:
        """Tokenize → lowercase → remove stopwords & punct → lemmatize."""
        tokens = [t.lower() for t in tokens if t.isalpha() and len(t) > 2]
        tokens = [t for t in tokens if t not in self.stop_words]
        if self.lemmatizer:
            tokens = [self.lemmatizer.lemmatize(t) for t in tokens]
        return tokens

    # ── Title Detection ───────────────────────────────────────────

    def _detect_title(self, text: str) -> str:
        lines = [l.strip() for l in text.split('\n') if l.strip()]
        for line in lines[:8]:
            if 10 < len(line) < 200 and not line.endswith('.'):
                # Skip author-like lines
                if not re.match(r'^[A-Z][a-z]+\s+[A-Z][a-z]+', line) or len(line) > 40:
                    return line
        return lines[0][:120] if lines else "Untitled Paper"

    # ── Author Detection ──────────────────────────────────────────

    def _detect_authors(self, text: str) -> list:
        """Simple NER-based author detection from first 1000 chars."""
        authors = []
        head = text[:1500]

        # Pattern: lines with 2-4 capitalized words (likely names)
        name_pattern = re.compile(
            r'\b([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+)\b'
        )
        matches = name_pattern.findall(head)

        # Filter out common non-name patterns
        skip = {'Abstract', 'Introduction', 'University', 'Department', 'Institute',
                'School', 'College', 'Figure', 'Table', 'This Paper', 'We Present'}
        for m in matches:
            if m not in skip and len(m.split()) >= 2:
                authors.append(m)
            if len(authors) >= 5:
                break

        return list(dict.fromkeys(authors)) or ["Authors not detected"]

    # ── Section Detection ─────────────────────────────────────────

    def _detect_sections(self, text: str, sentences: list) -> list:
        """Detect paper sections and generate a summary for each."""
        section_headers = [
            'abstract', 'introduction', 'background', 'related work', 'literature review',
            'methodology', 'methods', 'approach', 'proposed method', 'experimental setup',
            'experiments', 'results', 'evaluation', 'discussion', 'analysis',
            'conclusion', 'future work', 'references', 'acknowledgements'
        ]

        sections = []
        lines = text.split('\n')
        current_section = None
        current_content = []

        for line in lines:
            stripped = line.strip()
            is_header = False

            if stripped and len(stripped) < 80:
                lower = stripped.lower()
                for h in section_headers:
                    if lower.startswith(h) or re.match(rf'^\d+\.?\s+{re.escape(h)}', lower):
                        if current_section and current_content:
                            content = ' '.join(current_content)
                            sections.append({
                                'title': current_section,
                                'summary': self._extractive_summary(content, 2),
                                'word_count': len(content.split())
                            })
                        current_section = stripped
                        current_content = []
                        is_header = True
                        break

            if not is_header and current_section:
                current_content.append(stripped)

        # Last section
        if current_section and current_content:
            content = ' '.join(current_content)
            sections.append({
                'title': current_section,
                'summary': self._extractive_summary(content, 2),
                'word_count': len(content.split())
            })

        # Fallback: chunk text into 5 sections if none detected
        if not sections:
            chunk_size = max(1, len(sentences) // 5)
            default_names = ['Introduction', 'Background', 'Methodology', 'Results', 'Conclusion']
            for i, name in enumerate(default_names):
                chunk = sentences[i*chunk_size:(i+1)*chunk_size]
                content = ' '.join(chunk)
                sections.append({
                    'title': name,
                    'summary': self._extractive_summary(content, 2),
                    'word_count': len(content.split())
                })

        return sections[:10]

    # ── Keyword Extraction (TF-IDF) ───────────────────────────────

    def _extract_keywords(self, text: str, word_freq: Counter, top_n: int = 15) -> list:
        """TF-IDF keyword extraction with bigram support."""
        sentences = self._sent_tokenize(text)
        n_docs = len(sentences)
        if n_docs == 0:
            return []

        # Term frequency across whole doc
        total_words = sum(word_freq.values())

        # Document frequency (how many sentences contain each term)
        doc_freq = Counter()
        for sent in sentences:
            words_in_sent = set(self._clean_tokens(self._word_tokenize(sent)))
            doc_freq.update(words_in_sent)

        # TF-IDF score
        tfidf = {}
        for word, count in word_freq.items():
            if len(word) < 3:
                continue
            tf = count / max(total_words, 1)
            idf = math.log((n_docs + 1) / (doc_freq[word] + 1)) + 1
            tfidf[word] = tf * idf

        # Get top N
        top_keywords = sorted(tfidf.items(), key=lambda x: x[1], reverse=True)[:top_n]
        return [{"word": w, "score": round(s, 4), "freq": word_freq[w]} for w, s in top_keywords]

    # ── Extractive Summary (TextRank-style) ───────────────────────

    def _extractive_summary(self, text: str, num_sentences: int = 4) -> str:
        """Simple extractive summary: score sentences by keyword overlap."""
        sentences = self._sent_tokenize(text)
        if len(sentences) <= num_sentences:
            return text[:800]

        words = self._word_tokenize(text)
        clean = self._clean_tokens(words)
        word_freq = Counter(clean)
        max_freq = max(word_freq.values(), default=1)

        scores = {}
        for i, sent in enumerate(sentences):
            sent_words = self._clean_tokens(self._word_tokenize(sent))
            score = sum(word_freq.get(w, 0) / max_freq for w in sent_words)
            # Boost first and last sentences (typically key sentences)
            if i == 0: score *= 1.5
            if i == len(sentences) - 1: score *= 1.2
            scores[i] = score

        top_indices = sorted(sorted(scores, key=scores.get, reverse=True)[:num_sentences])
        return ' '.join(sentences[i] for i in top_indices)

    # ── AI Analysis (Anthropic API) ───────────────────────────────

    def _ai_analysis(self, text: str, title: str, sections: list) -> dict:
        """Use Anthropic API for high-quality structured analysis."""
        if ANTHROPIC_OK:
            return self._anthropic_analysis(text, title)
        return self._rule_based_analysis(text, sections)

    def _anthropic_analysis(self, text: str, title: str) -> dict:
        """Call Claude API for structured analysis."""
        # Truncate to fit context window
        truncated = text[:8000]

        prompt = f"""You are an expert academic research analyst. Analyze the following research paper and return a JSON object with exactly these fields:

{{
  "abstract_summary": "2-3 sentence summary of the abstract/paper objective",
  "full_summary": "5-7 sentence comprehensive summary of the entire paper",
  "key_findings": ["finding 1", "finding 2", "finding 3", "finding 4", "finding 5"],
  "problem_statement": "1-2 sentence description of the research problem",
  "methodology": "2-3 sentence description of the research methodology",
  "results_analysis": "2-3 sentence analysis of results and performance metrics",
  "conclusion": "2-3 sentence paper conclusion",
  "research_gaps": ["gap 1", "gap 2", "gap 3", "gap 4"],
  "future_scope": ["scope 1", "scope 2", "scope 3", "scope 4"],
  "recommendations": ["rec 1", "rec 2", "rec 3"]
}}

Return ONLY the JSON. No explanation, no markdown, no backticks.

PAPER TITLE: {title}

PAPER TEXT:
{truncated}"""

        try:
            message = anthropic_client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}]
            )
            response_text = message.content[0].text.strip()
            # Strip any accidental markdown
            response_text = re.sub(r'^```json?\s*', '', response_text)
            response_text = re.sub(r'\s*```$', '', response_text)
            return json.loads(response_text)
        except Exception as e:
            print(f"[AI] Anthropic call failed: {e}, falling back to rule-based")
            return self._rule_based_analysis(text, [])

    def _rule_based_analysis(self, text: str, sections: list) -> dict:
        """Rule-based fallback analysis when AI is unavailable."""
        sentences = self._sent_tokenize(text)
        words = self._word_tokenize(text)
        clean = self._clean_tokens(words)
        freq = Counter(clean)

        abstract_sents = sentences[:8] if len(sentences) > 8 else sentences[:3]
        abstract_summary = self._extractive_summary(' '.join(abstract_sents), 2)
        full_summary = self._extractive_summary(text, 6)

        # Extract key sentences as "findings"
        key_sentences = sorted(
            [(i, s) for i, s in enumerate(sentences) if len(s) > 40],
            key=lambda x: sum(freq.get(w.lower(), 0) for w in x[1].split()),
            reverse=True
        )[:5]
        key_findings = [s for _, s in sorted(key_sentences, key=lambda x: x[0])]

        # Detect methodology indicators
        method_keywords = ['proposed', 'method', 'approach', 'algorithm', 'technique',
                          'framework', 'model', 'system', 'architecture', 'using']
        method_sents = [s for s in sentences if any(k in s.lower() for k in method_keywords)]
        methodology = method_sents[0][:400] if method_sents else sentences[len(sentences)//3][:400]

        # Detect results
        result_keywords = ['result', 'achieve', 'accuracy', 'performance', 'outperform',
                           'improve', 'show', 'demonstrate', 'evaluate', 'score', '%']
        result_sents = [s for s in sentences if any(k in s.lower() for k in result_keywords)]
        results_analysis = result_sents[0][:400] if result_sents else "Results not explicitly detected."

        # Detect conclusion
        conclusion_text = ""
        for sect in sections:
            if 'conclusion' in sect.get('title', '').lower():
                conclusion_text = sect.get('summary', '')
                break
        if not conclusion_text:
            conclusion_text = sentences[-min(5, len(sentences))][:400]

        # Problem statement (early sentences)
        problem_text = sentences[1][:400] if len(sentences) > 1 else sentences[0][:400]

        # Research gaps from limitation/gap keywords
        gap_kw = ['however', 'limitation', 'gap', 'challenge', 'future', 'lack', 'not address']
        gap_sents = [s for s in sentences if any(k in s.lower() for k in gap_kw)][:4]
        research_gaps = gap_sents if gap_sents else [
            "Further validation on diverse datasets is needed",
            "Computational complexity requires optimization",
            "Cross-domain generalization not fully explored"
        ]

        # Future scope
        future_kw = ['future', 'extend', 'further', 'improve', 'plan to', 'will investigate']
        future_sents = [s for s in sentences if any(k in s.lower() for k in future_kw)][:4]
        future_scope = future_sents if future_sents else [
            "Real-world deployment and scalability testing",
            "Integration with multimodal data sources",
            "Evaluation on larger, more diverse datasets"
        ]

        return {
            "abstract_summary":  abstract_summary,
            "full_summary":      full_summary,
            "key_findings":      key_findings,
            "problem_statement": problem_text,
            "methodology":       methodology,
            "results_analysis":  results_analysis,
            "conclusion":        conclusion_text,
            "research_gaps":     research_gaps,
            "future_scope":      future_scope,
            "recommendations":   [
                "Review references carefully for completeness",
                "Validate results with an independent dataset",
                "Consider ablation studies for key components"
            ]
        }

    # ── Sentiment Analysis ────────────────────────────────────────

    def _sentiment_analysis(self, text: str):
        """VADER-based sentiment + academic tone detection."""
        if not self.sia:
            return "Analytical", {"analytical": 65, "positive": 25, "neutral": 10}

        scores = self.sia.polarity_scores(text[:5000])
        compound = scores['compound']

        # Academic papers are mostly analytical/neutral
        analytical_words = ['propose', 'investigate', 'analyze', 'evaluate', 'compare',
                           'demonstrate', 'present', 'examine', 'study', 'assess',
                           'implement', 'develop', 'method', 'approach', 'result']
        text_lower = text.lower()
        analytical_count = sum(1 for w in analytical_words if w in text_lower)

        if analytical_count > 10:
            label = "Analytical"
            s = {"analytical": 65 + min(analytical_count, 20), "positive": 20, "neutral": 15}
        elif compound > 0.2:
            label = "Positive"
            s = {"analytical": 45, "positive": 45, "neutral": 10}
        else:
            label = "Neutral"
            s = {"analytical": 40, "positive": 20, "neutral": 40}

        total = sum(s.values())
        s = {k: round(v / total * 100) for k, v in s.items()}
        return label, s

    # ── Complexity Score ──────────────────────────────────────────

    def _complexity_score(self, text: str, words: list, clean_words: list):
        """Multi-factor complexity scoring."""
        sentences = self._sent_tokenize(text)

        avg_sentence_len = len(words) / max(len(sentences), 1)
        unique_ratio = len(set(clean_words)) / max(len(clean_words), 1)

        # Technical term density
        tech_terms = re.findall(
            r'\b(algorithm|neural|transformer|optimization|methodology|hypothesis|'
            r'empirical|regression|classifier|network|gradient|epoch|variance|'
            r'statistical|coefficient|benchmark|architecture|embedding)\b',
            text, re.I
        )
        tech_density = len(tech_terms) / max(len(words) / 100, 1)

        score = 0
        score += min(3, avg_sentence_len / 10)      # 0–3 pts
        score += min(3, unique_ratio * 4)            # 0–3 pts
        score += min(4, tech_density / 2)            # 0–4 pts
        score = round(min(10, score), 1)

        label = "Easy" if score < 4 else "Medium" if score < 7 else "Hard"
        return score, label

    def _complexity_breakdown(self, text: str, words: list, clean: list) -> dict:
        sents = self._sent_tokenize(text)
        avg_len = len(words) / max(len(sents), 1)
        unique_r = len(set(clean)) / max(len(clean), 1)
        tech = len(re.findall(r'\b(algorithm|neural|model|method|theorem|equation)\b', text, re.I))
        return {
            "vocabulary":       min(10, round(unique_r * 12)),
            "sentence_length":  min(10, round(avg_len / 4)),
            "technical_density": min(10, round(tech / max(len(words)/100, 1))),
            "abstraction":      min(10, 5 + round(unique_r * 5)),
            "formula_usage":    min(10, len(re.findall(r'[=+\-*/∑∫∂∈]', text)) // 5)
        }

    # ── Readability Score (Flesch) ────────────────────────────────

    def _readability_score(self, text: str, sentences: list, words: list) -> int:
        """Flesch Reading Ease score mapped to 0-100."""
        syllables = sum(self._count_syllables(w) for w in words)
        n_words = max(len(words), 1)
        n_sents = max(len(sentences), 1)

        flesch = 206.835 - 1.015 * (n_words / n_sents) - 84.6 * (syllables / n_words)
        return max(0, min(100, int(flesch)))

    @staticmethod
    def _count_syllables(word: str) -> int:
        word = word.lower()
        count = 0
        vowels = 'aeiouy'
        prev_vowel = False
        for ch in word:
            is_vowel = ch in vowels
            if is_vowel and not prev_vowel:
                count += 1
            prev_vowel = is_vowel
        if word.endswith('e') and count > 1:
            count -= 1
        return max(1, count)

    # ── Novelty Score ─────────────────────────────────────────────

    def _novelty_score(self, text: str, keywords: list) -> int:
        """Heuristic novelty score based on novel terms and claims."""
        novelty_indicators = ['novel', 'new', 'first', 'propose', 'our approach',
                             'we introduce', 'we present', 'innovative', 'state-of-the-art',
                             'outperform', 'improve', 'advance', 'contribution']
        text_lower = text.lower()
        count = sum(1 for term in novelty_indicators if term in text_lower)
        return min(10, max(1, count))

    # ── Citation Extraction ───────────────────────────────────────

    def _extract_citations(self, text: str) -> list:
        """Extract citation strings from reference section."""
        # Find reference section
        ref_match = re.search(
            r'(?:references|bibliography|works cited)\s*\n(.*)',
            text, re.I | re.DOTALL
        )
        section = ref_match.group(1) if ref_match else text[-3000:]

        # Match numbered references [1], (1), or author-year
        patterns = [
            r'\[\d+\]\s+.{20,200}',          # [1] Author...
            r'\(\d+\)\s+.{20,200}',           # (1) Author...
            r'[A-Z][a-z]+,?\s+[A-Z]\..*?\(\d{4}\).*?(?=\n[A-Z]|\Z)',  # APA style
        ]
        citations = []
        for pat in patterns:
            found = re.findall(pat, section, re.DOTALL)
            citations.extend([c.strip()[:200] for c in found if len(c.strip()) > 30])
            if citations:
                break

        return list(dict.fromkeys(citations))[:50]  # Deduplicate, max 50

    def _detect_citation_style(self, text: str) -> str:
        ieee = len(re.findall(r'\[\d+\]', text))
        apa = len(re.findall(r'\((?:[A-Z][a-z]+,?\s+)?(?:et al\.?,?\s+)?\d{4}\)', text))
        mla = len(re.findall(r'\((?:[A-Z][a-z]+ \d+|[A-Z][a-z]+)\)', text))
        if ieee >= max(apa, mla): return "IEEE"
        if apa >= mla: return "APA"
        return "MLA"

    def _count_self_citations(self, citations: list, authors: list) -> int:
        if not authors or not citations:
            return 0
        last_names = [a.split()[-1].lower() for a in authors if a != "Authors not detected"]
        return sum(1 for c in citations if any(ln in c.lower() for ln in last_names))

    # ── Algorithm Detection ───────────────────────────────────────

    def _detect_algorithms(self, text: str) -> list:
        algorithm_patterns = [
            r'\b(BERT|GPT(?:-\d+)?|T5|RoBERTa|XLNet|DistilBERT|ALBERT|ELECTRA)\b',
            r'\b(CNN|RNN|LSTM|GRU|GAN|VAE|Transformer|Attention)\b',
            r'\b(SVM|Random Forest|Decision Tree|KNN|Naive Bayes|Logistic Regression)\b',
            r'\b(K-means|DBSCAN|PCA|t-SNE|UMAP|Word2Vec|GloVe|FastText)\b',
            r'\b(ResNet|VGG|YOLO|EfficientNet|MobileNet|InceptionNet)\b',
            r'\b(Adam|SGD|AdaGrad|RMSprop|LAMB)\b',
            r'\b(TF-IDF|TextRank|RAKE|LDA|LSA|NMF)\b',
            r'\b(reinforcement learning|transfer learning|federated learning|meta-learning)\b',
            r'\b(backpropagation|gradient descent|cross-entropy|softmax|sigmoid)\b',
        ]
        found = []
        for pattern in algorithm_patterns:
            matches = re.findall(pattern, text, re.I)
            found.extend([m.strip() for m in matches])
        return list(dict.fromkeys(found))[:12]

    # ── Dataset Detection ─────────────────────────────────────────

    def _detect_datasets(self, text: str) -> list:
        dataset_patterns = [
            r'\b(ImageNet|COCO|CIFAR-(?:10|100)|MNIST|Fashion-MNIST)\b',
            r'\b(GLUE|SuperGLUE|SQuAD|CoNLL|WMT-\d+|SNLI|MultiNLI)\b',
            r'\b(UCI|Kaggle|IMDB|SST-[12]|20 ?Newsgroups|Reuters)\b',
            r'\b(MS[-\s]?COCO|Open Images|LAION|Common Crawl)\b',
            r'\b(Penn Treebank|Wikipedia|BookCorpus|C4|The Pile)\b',
            r'(?:dataset|corpus|benchmark)[^\n]*?(?:named|called|:\s*)([A-Z][A-Za-z0-9\-]+)',
        ]
        found = []
        for pat in dataset_patterns:
            matches = re.findall(pat, text, re.I)
            if isinstance(matches[0] if matches else '', tuple):
                found.extend([m[-1] for m in matches])
            else:
                found.extend(matches)
        return list(dict.fromkeys(found))[:8]

    # ── NER with spaCy ────────────────────────────────────────────

    def _extract_entities(self, text: str) -> dict:
        if not SPACY_OK:
            return {}
        doc = nlp_spacy(text[:10000])
        entities = {}
        for ent in doc.ents:
            label = ent.label_
            if label not in entities:
                entities[label] = []
            if ent.text not in entities[label]:
                entities[label].append(ent.text)
        return {k: v[:8] for k, v in entities.items()}

    # ── Topic Detection ───────────────────────────────────────────

    def _detect_topics(self, clean_words: list, keywords: list) -> list:
        """Heuristic topic detection from keyword clusters."""
        topic_map = {
            "🤖 Machine Learning": ['learning', 'model', 'train', 'classification', 'regression'],
            "🧠 Deep Learning": ['neural', 'network', 'layer', 'gradient', 'deep'],
            "💬 NLP": ['language', 'text', 'nlp', 'word', 'sentence', 'bert', 'transformer'],
            "👁️ Computer Vision": ['image', 'visual', 'cnn', 'detection', 'recognition'],
            "📊 Data Analysis": ['data', 'analysis', 'statistic', 'dataset', 'feature'],
            "🔐 Security": ['security', 'attack', 'adversarial', 'privacy', 'robust'],
            "🌐 Network Science": ['graph', 'node', 'edge', 'network', 'cluster'],
            "⚕️ Healthcare": ['medical', 'clinical', 'patient', 'health', 'diagnosis'],
            "🎮 Reinforcement Learning": ['reward', 'agent', 'policy', 'action', 'environment'],
        }
        word_set = set(clean_words)
        kw_words = {k['word'].lower() for k in keywords}
        detected = []
        for topic, terms in topic_map.items():
            if sum(1 for t in terms if t in word_set or t in kw_words) >= 2:
                detected.append(topic)
        return detected or ["📖 General Research", "🔬 Empirical Study"]

    # ── Figure Detection ──────────────────────────────────────────

    def _detect_figures(self, text: str) -> list:
        """Detect figure captions in text."""
        pattern = re.compile(
            r'(?:Figure|Fig\.?|FIGURE)\s+(\d+)[:\.]?\s*([^\n]{10,150})',
            re.I
        )
        figures = []
        for m in pattern.finditer(text):
            figures.append({
                "caption": f"Figure {m.group(1)}: {m.group(2).strip()}",
                "description": f"Detected figure reference in paper: {m.group(2).strip()}"
            })
        return figures[:8]

    # ── AI Chat (QA) ─────────────────────────────────────────────

    def _ai_chat(self, question: str, paper_text: str) -> str:
        """Use Anthropic API to answer question about the paper."""
        truncated = paper_text[:6000]
        prompt = f"""You are a research paper assistant. Answer the user's question based ONLY on the paper text provided. 
Be concise, specific, and cite relevant parts of the paper.

PAPER TEXT:
{truncated}

QUESTION: {question}

Provide a helpful, focused answer in 2-4 sentences."""

        message = anthropic_client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}]
        )
        return message.content[0].text.strip()

    def _rule_based_chat(self, question: str, paper_text: str) -> str:
        """Simple rule-based QA fallback."""
        q = question.lower()
        sentences = self._sent_tokenize(paper_text)

        # Find most relevant sentences
        q_words = set(self._clean_tokens(q.split()))
        scored = []
        for s in sentences:
            s_words = set(self._clean_tokens(s.split()))
            overlap = len(q_words & s_words)
            if overlap > 0:
                scored.append((overlap, s))
        scored.sort(reverse=True)
        if scored:
            return ' '.join(s for _, s in scored[:2])
        return "I couldn't find a specific answer to that question in the paper. Please try rephrasing or ask about a different aspect."
