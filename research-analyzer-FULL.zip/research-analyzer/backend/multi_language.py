"""
========================================================
multi_language.py — Multi-Language Support
========================================================
Handles:
  - Language detection of input paper
  - Translation of paper text to English (for NLP)
  - Translation of analysis outputs back to user's language
  - UI language mapping

Endpoint: POST /api/translate
Body:    { "text": "...", "target_lang": "es" }
Returns: { "translated": "...", "detected_lang": "en" }
========================================================
"""

import re
import os

# ── Optional: Google Translate / Deep Translate ───────────────────
try:
    from deep_translator import GoogleTranslator
    TRANSLATOR_OK = True
except ImportError:
    TRANSLATOR_OK = False
    print("[WARN] deep-translator not installed: pip install deep-translator")

# ── Supported Languages ───────────────────────────────────────────
SUPPORTED_LANGUAGES = {
    "en": "English",
    "hi": "Hindi",
    "es": "Spanish",
    "fr": "French",
    "de": "German",
    "zh-CN": "Chinese (Simplified)",
    "ar": "Arabic",
    "pt": "Portuguese",
    "ru": "Russian",
    "ja": "Japanese",
    "ko": "Korean",
    "it": "Italian",
    "nl": "Dutch",
    "tr": "Turkish",
    "pl": "Polish",
    "sv": "Swedish",
    "no": "Norwegian",
    "bn": "Bengali",
    "gu": "Gujarati",
    "mr": "Marathi",
    "ta": "Tamil",
    "te": "Telugu",
}

# Common words for basic language detection
LANG_INDICATORS = {
    "en": ["the", "and", "of", "to", "a", "in", "is", "that", "for", "it"],
    "es": ["el", "la", "los", "en", "que", "de", "por", "con", "una", "para"],
    "fr": ["le", "la", "les", "de", "et", "en", "que", "pour", "un", "une"],
    "de": ["die", "der", "und", "in", "den", "von", "mit", "das", "ist", "sich"],
    "pt": ["o", "a", "os", "as", "de", "em", "que", "para", "um", "uma"],
    "it": ["il", "la", "di", "e", "che", "in", "un", "una", "con", "per"],
    "ar": ["في", "من", "على", "إلى", "أن", "ما", "هذا", "كان", "له", "وقد"],
    "zh-CN": ["的", "了", "在", "是", "我", "有", "他", "这", "为", "之"],
    "hi": ["और", "है", "में", "की", "के", "एक", "से", "को", "पर", "था"],
    "gu": ["અને", "છે", "માં", "ની", "ના", "એક", "થી", "ને", "પર", "હતો"],
}


# ══════════════════════════════════════════════════════════════════
class MultiLanguageHandler:

    def detect_language(self, text: str) -> str:
        """
        Detect the language of text using indicator word matching.
        Returns ISO 639-1 code (e.g., 'en', 'es', 'hi').
        """
        sample = text[:2000].lower()
        words = re.findall(r'\b\w+\b', sample)
        word_set = set(words)

        scores = {}
        for lang_code, indicators in LANG_INDICATORS.items():
            scores[lang_code] = sum(1 for w in indicators if w in word_set)

        if not scores or max(scores.values()) < 2:
            return "en"

        return max(scores, key=scores.get)

    def translate(self, text: str, target_lang: str = "en",
                  source_lang: str = "auto") -> str:
        """
        Translate text to target_lang.
        Falls back to returning original text if translation unavailable.
        """
        if source_lang == target_lang or target_lang == "en" and self._is_english(text):
            return text

        if not text.strip():
            return text

        if TRANSLATOR_OK:
            return self._google_translate(text, target_lang, source_lang)
        else:
            # Without translator — return original with note
            lang_name = SUPPORTED_LANGUAGES.get(target_lang, target_lang)
            return f"[Translation to {lang_name} requires: pip install deep-translator]\n\n{text}"

    def translate_analysis_output(self, analysis: dict, target_lang: str) -> dict:
        """
        Translate key analysis fields (summaries, findings, etc.)
        to the target language.
        """
        if target_lang == "en":
            return analysis

        # Fields to translate
        text_fields = [
            "abstract_summary", "full_summary", "problem_statement",
            "methodology", "results_analysis", "conclusion"
        ]
        list_fields = [
            "key_findings", "research_gaps", "future_scope", "recommendations"
        ]

        result = dict(analysis)

        for field in text_fields:
            if field in result and result[field]:
                result[field] = self.translate(str(result[field]), target_lang)

        for field in list_fields:
            if field in result and isinstance(result[field], list):
                result[field] = [
                    self.translate(str(item), target_lang)
                    for item in result[field][:5]   # Translate first 5 only (API cost)
                ]

        result["translated_to"] = SUPPORTED_LANGUAGES.get(target_lang, target_lang)
        return result

    def _google_translate(self, text: str, target: str, source: str = "auto") -> str:
        """Translate using deep-translator (Google backend)."""
        try:
            # deep-translator has 5000 char limit per call
            if len(text) <= 5000:
                return GoogleTranslator(source=source, target=target).translate(text)
            else:
                # Split into chunks
                chunks = [text[i:i+4500] for i in range(0, len(text), 4500)]
                translated_chunks = [
                    GoogleTranslator(source=source, target=target).translate(chunk)
                    for chunk in chunks
                ]
                return ' '.join(translated_chunks)
        except Exception as e:
            print(f"[MultiLang] Translation failed: {e}")
            return text

    def _is_english(self, text: str) -> bool:
        return self.detect_language(text) == "en"

    def get_language_name(self, code: str) -> str:
        return SUPPORTED_LANGUAGES.get(code, code)

    def list_supported_languages(self) -> list:
        return [{"code": k, "name": v} for k, v in SUPPORTED_LANGUAGES.items()]
