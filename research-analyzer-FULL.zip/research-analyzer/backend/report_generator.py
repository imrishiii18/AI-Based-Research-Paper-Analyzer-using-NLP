"""
========================================================
PDF Report Generator
========================================================
Generates a downloadable, professionally formatted PDF
analysis report from the analysis JSON data.

Uses: reportlab (pip install reportlab)
Fallback: fpdf2 (pip install fpdf2)
========================================================
"""

import os
import json
from datetime import datetime
from typing import Any

REPORT_DIR = 'reports'
os.makedirs(REPORT_DIR, exist_ok=True)


def generate_pdf_report(data: dict) -> str:
    """
    Generate a PDF report from analysis data.
    Returns path to the generated PDF file.
    """
    output_path = os.path.join(REPORT_DIR, 'research_analysis_report.pdf')

    # Try reportlab first
    try:
        return _generate_with_reportlab(data, output_path)
    except ImportError:
        pass

    # Fallback to fpdf2
    try:
        return _generate_with_fpdf(data, output_path)
    except ImportError:
        pass

    # Last resort: plain text "PDF" (actually TXT)
    txt_path = output_path.replace('.pdf', '.txt')
    return _generate_text_report(data, txt_path)


# ── ReportLab Generator ───────────────────────────────────────────

def _generate_with_reportlab(data: dict, output_path: str) -> str:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib.colors import HexColor, white, black
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        HRFlowable, PageBreak, KeepTogether
    )
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY

    # Colour palette
    INDIGO = HexColor('#6366f1')
    VIOLET = HexColor('#8b5cf6')
    DARK   = HexColor('#0d1224')
    GREY   = HexColor('#64748b')
    LIGHT  = HexColor('#f0f2ff')
    CYAN   = HexColor('#22d3ee')

    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        rightMargin=2*cm, leftMargin=2*cm,
        topMargin=2*cm, bottomMargin=2*cm,
        title="Research Paper Analysis Report"
    )

    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle('TitleStyle', parent=styles['Title'],
        fontSize=22, textColor=INDIGO, spaceAfter=8,
        fontName='Helvetica-Bold', alignment=TA_CENTER)

    subtitle_style = ParagraphStyle('SubtitleStyle', parent=styles['Normal'],
        fontSize=11, textColor=GREY, spaceAfter=4, alignment=TA_CENTER)

    h2_style = ParagraphStyle('H2Style', parent=styles['Heading2'],
        fontSize=13, textColor=INDIGO, spaceBefore=16, spaceAfter=6,
        fontName='Helvetica-Bold', borderPad=4)

    h3_style = ParagraphStyle('H3Style', parent=styles['Heading3'],
        fontSize=11, textColor=VIOLET, spaceBefore=10, spaceAfter=4,
        fontName='Helvetica-Bold')

    body_style = ParagraphStyle('BodyStyle', parent=styles['Normal'],
        fontSize=10, textColor=HexColor('#1e293b'), spaceAfter=6,
        leading=16, alignment=TA_JUSTIFY)

    mono_style = ParagraphStyle('MonoStyle', parent=styles['Code'],
        fontSize=9, textColor=GREY, spaceAfter=4, leading=14)

    bullet_style = ParagraphStyle('BulletStyle', parent=styles['Normal'],
        fontSize=10, textColor=HexColor('#334155'), spaceAfter=4,
        leading=15, leftIndent=16, bulletIndent=0)

    story = []

    # ── Cover Page ──────────────────────────────────────────────
    story.append(Spacer(1, 1.5*cm))

    # Logo/badge placeholder
    story.append(Paragraph("🔬 AI Research Paper Analyzer", title_style))
    story.append(Spacer(1, 0.4*cm))
    story.append(Paragraph("BSc Data Science Major Project | NLP Intelligence Platform", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=2, color=INDIGO, spaceAfter=14))

    story.append(Spacer(1, 0.6*cm))

    # Paper info table
    title = data.get('title', 'Research Paper')
    authors = ', '.join(data.get('authors', ['Unknown']))
    gen_date = datetime.now().strftime('%B %d, %Y %H:%M')

    info_data = [
        ['Paper Title', title[:80]],
        ['Authors', authors[:80]],
        ['Word Count', str(data.get('word_count', '—'))],
        ['Sentences', str(data.get('sentence_count', '—'))],
        ['Citations', str(data.get('citation_count', '—'))],
        ['Complexity', f"{data.get('complexity_label', '—')} ({data.get('complexity_score', '—')}/10)"],
        ['Novelty Score', f"{data.get('novelty_score', '—')}/10"],
        ['Sentiment', data.get('sentiment', '—')],
        ['Generated', gen_date],
    ]

    t = Table(info_data, colWidths=[5*cm, 12*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), LIGHT),
        ('TEXTCOLOR', (0, 0), (0, -1), INDIGO),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('ROWBACKGROUNDS', (0, 0), (-1, -1), [white, HexColor('#f8f9ff')]),
        ('BOX', (0, 0), (-1, -1), 0.5, HexColor('#dde0f5')),
        ('INNERGRID', (0, 0), (-1, -1), 0.25, HexColor('#dde0f5')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
    ]))
    story.append(t)
    story.append(PageBreak())

    # ── Section Helper ──────────────────────────────────────────
    def section(heading: str, icon: str = ""):
        story.append(HRFlowable(width="100%", thickness=1, color=HexColor('#e2e8f0'), spaceBefore=6, spaceAfter=2))
        story.append(Paragraph(f"{icon} {heading}" if icon else heading, h2_style))

    def sub(heading: str):
        story.append(Paragraph(heading, h3_style))

    def body(text: str):
        if text:
            story.append(Paragraph(str(text)[:2000], body_style))

    def bullets(items: list, icon: str = "•"):
        for item in (items or [])[:10]:
            story.append(Paragraph(f"{icon} {str(item)[:200]}", bullet_style))

    # ── 1. Summary ──────────────────────────────────────────────
    section("1. Summary & Overview", "📄")
    sub("Abstract Summary")
    body(data.get('abstract_summary', ''))
    story.append(Spacer(1, 0.3*cm))

    sub("Full Paper Summary")
    body(data.get('full_summary', ''))
    story.append(Spacer(1, 0.3*cm))

    sub("Problem Statement")
    body(data.get('problem_statement', ''))
    story.append(Spacer(1, 0.3*cm))

    sub("Key Findings")
    bullets(data.get('key_findings', []), "✅")
    story.append(PageBreak())

    # ── 2. Technical Analysis ───────────────────────────────────
    section("2. Technical Analysis", "🔬")

    sub("Methodology")
    body(data.get('methodology', ''))

    sub("Algorithms Detected")
    bullets(data.get('algorithms', []), "⚙️")

    sub("Datasets Referenced")
    bullets(data.get('datasets', []), "🗄️")

    sub("Results Analysis")
    body(data.get('results_analysis', ''))

    sub("Conclusion")
    body(data.get('conclusion', ''))

    # Scores table
    sub("Scores Overview")
    score_data = [
        ['Metric', 'Score', 'Label'],
        ['Complexity', f"{data.get('complexity_score','—')}/10", data.get('complexity_label','—')],
        ['Readability (Flesch)', f"{data.get('readability_score','—')}/100", ''],
        ['Novelty', f"{data.get('novelty_score','—')}/10", ''],
        ['Writing Sentiment', '', data.get('sentiment','—')],
    ]
    st = Table(score_data, colWidths=[7*cm, 4*cm, 6*cm])
    st.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), INDIGO),
        ('TEXTCOLOR', (0, 0), (-1, 0), white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, LIGHT]),
        ('BOX', (0, 0), (-1, -1), 0.5, HexColor('#c7d2fe')),
        ('INNERGRID', (0, 0), (-1, -1), 0.25, HexColor('#dde0f5')),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(st)
    story.append(PageBreak())

    # ── 3. Keywords & Topics ────────────────────────────────────
    section("3. Keywords & Topics", "🔑")
    kws = data.get('keywords', [])
    kw_text = '  ·  '.join(k.get('word', str(k)) for k in kws[:20])
    story.append(Paragraph(kw_text, body_style))
    story.append(Spacer(1, 0.3*cm))

    sub("Detected Topics")
    bullets(data.get('topics', []), "🏷️")

    # ── 4. Section-wise Summaries ───────────────────────────────
    section("4. Section-wise Summaries", "📝")
    for sect in data.get('sections', [])[:8]:
        sub(sect.get('title', 'Section'))
        body(sect.get('summary', ''))
        story.append(Spacer(1, 0.2*cm))

    story.append(PageBreak())

    # ── 5. Citations ────────────────────────────────────────────
    section("5. Citations & References", "📋")
    story.append(Paragraph(
        f"Citation Style: <b>{data.get('citation_style','—')}</b>  |  "
        f"Total: <b>{data.get('citation_count','0')}</b>  |  "
        f"Self-citations: <b>{data.get('self_citations','0')}</b>",
        body_style
    ))
    story.append(Spacer(1, 0.3*cm))
    for i, c in enumerate(data.get('citations', [])[:30], 1):
        story.append(Paragraph(f"[{i}] {c}", mono_style))

    story.append(PageBreak())

    # ── 6. Research Gaps & Future Scope ─────────────────────────
    section("6. Research Gaps & Future Scope", "🔮")
    sub("Research Gaps Identified")
    bullets(data.get('research_gaps', []), "⚠️")
    story.append(Spacer(1, 0.3*cm))

    sub("Future Scope Predictions")
    bullets(data.get('future_scope', []), "🚀")
    story.append(Spacer(1, 0.3*cm))

    sub("AI Recommendations")
    bullets(data.get('recommendations', []), "⭐")

    # ── Footer ───────────────────────────────────────────────────
    story.append(Spacer(1, 1*cm))
    story.append(HRFlowable(width="100%", thickness=1, color=INDIGO))
    story.append(Paragraph(
        f"Report generated on {gen_date} by AI Research Paper Analyzer | BSc Data Science Major Project",
        ParagraphStyle('Footer', parent=styles['Normal'],
            fontSize=8, textColor=GREY, alignment=TA_CENTER, spaceBefore=6)
    ))

    doc.build(story)
    return output_path


# ── FPDF2 Fallback ────────────────────────────────────────────────

def _generate_with_fpdf(data: dict, output_path: str) -> str:
    from fpdf import FPDF

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Title
    pdf.set_font('Helvetica', 'B', 20)
    pdf.set_text_color(99, 102, 241)
    pdf.cell(0, 12, 'AI Research Paper Analyzer', align='C', new_x='LMARGIN', new_y='NEXT')
    pdf.set_font('Helvetica', '', 11)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(0, 8, 'BSc Data Science Major Project - Analysis Report', align='C', new_x='LMARGIN', new_y='NEXT')
    pdf.ln(5)

    def section_head(title):
        pdf.set_font('Helvetica', 'B', 13)
        pdf.set_text_color(99, 102, 241)
        pdf.cell(0, 10, title, new_x='LMARGIN', new_y='NEXT')
        pdf.set_draw_color(99, 102, 241)
        pdf.line(10, pdf.get_y(), 200, pdf.get_y())
        pdf.ln(2)

    def body_text(text: str):
        if not text: return
        pdf.set_font('Helvetica', '', 10)
        pdf.set_text_color(30, 30, 60)
        pdf.multi_cell(0, 6, str(text)[:1500], new_x='LMARGIN', new_y='NEXT')
        pdf.ln(2)

    def bullet_list(items: list):
        pdf.set_font('Helvetica', '', 10)
        pdf.set_text_color(51, 65, 85)
        for item in (items or [])[:10]:
            pdf.cell(5, 6, chr(149), new_x='RIGHT', new_y='LAST')
            pdf.multi_cell(0, 6, ' ' + str(item)[:200], new_x='LMARGIN', new_y='NEXT')

    # Paper title
    pdf.set_font('Helvetica', 'B', 14)
    pdf.set_text_color(30, 30, 60)
    pdf.multi_cell(0, 8, data.get('title', 'Research Paper'), new_x='LMARGIN', new_y='NEXT')
    pdf.ln(4)

    section_head('1. Summary')
    body_text(data.get('abstract_summary', ''))
    body_text(data.get('full_summary', ''))

    section_head('2. Key Findings')
    bullet_list(data.get('key_findings', []))

    section_head('3. Technical Analysis')
    body_text('Methodology: ' + data.get('methodology', ''))
    pdf.set_font('Helvetica', 'B', 10)
    pdf.cell(0, 8, 'Algorithms:', new_x='LMARGIN', new_y='NEXT')
    bullet_list(data.get('algorithms', []))

    section_head('4. Research Gaps & Future Scope')
    bullet_list(data.get('research_gaps', []))
    bullet_list(data.get('future_scope', []))

    section_head('5. Keywords')
    kws = ', '.join(k.get('word', str(k)) for k in data.get('keywords', [])[:15])
    body_text(kws)

    pdf.output(output_path)
    return output_path


# ── Plain Text Fallback ───────────────────────────────────────────

def _generate_text_report(data: dict, output_path: str) -> str:
    sep = '=' * 60
    lines = [
        sep,
        'AI RESEARCH PAPER ANALYSIS REPORT',
        'BSc Data Science Major Project',
        sep,
        '',
        f"Title:      {data.get('title','')}",
        f"Authors:    {', '.join(data.get('authors',[]))}",
        f"Words:      {data.get('word_count','')}",
        f"Citations:  {data.get('citation_count','')}",
        f"Complexity: {data.get('complexity_label','')} ({data.get('complexity_score','')}/10)",
        f"Generated:  {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        '',
        sep, '1. ABSTRACT SUMMARY', sep,
        data.get('abstract_summary',''),
        '',
        sep, '2. FULL SUMMARY', sep,
        data.get('full_summary',''),
        '',
        sep, '3. KEY FINDINGS', sep,
        *[f'  {i+1}. {f}' for i,f in enumerate(data.get('key_findings',[]))],
        '',
        sep, '4. METHODOLOGY', sep,
        data.get('methodology',''),
        '',
        sep, '5. RESEARCH GAPS', sep,
        *[f'  • {g}' for g in data.get('research_gaps',[])],
        '',
        sep, '6. FUTURE SCOPE', sep,
        *[f'  • {f}' for f in data.get('future_scope',[])],
        '',
        sep, '7. KEYWORDS', sep,
        ', '.join(k.get('word',str(k)) for k in data.get('keywords',[])[:15]),
        '',
        sep,
        'Report generated by AI Research Paper Analyzer',
        sep,
    ]
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    return output_path
