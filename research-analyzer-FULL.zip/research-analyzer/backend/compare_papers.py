"""
========================================================
compare_papers.py — Paper Comparison Engine
========================================================
Compare two research papers side by side:
  - Keyword overlap / divergence
  - Topic similarity score
  - Citation overlap
  - Methodology comparison
  - Research gap intersection
  - Similarity heatmap

Endpoint: POST /api/compare
Body:    { "paper1": {...analysis_json}, "paper2": {...analysis_json} }
Returns: Comparison JSON
========================================================
"""

import re
import math
from collections import Counter
from typing import Any


# ══════════════════════════════════════════════════════════════════
class PaperComparator:

    def compare(self, paper1: dict, paper2: dict) -> dict:
        """
        Compare two analyzed paper results.
        Both paper1 and paper2 should be analysis dicts from nlp_processor.
        Returns a structured comparison result.
        """
        kw1 = self._kw_set(paper1)
        kw2 = self._kw_set(paper2)

        algo1 = set(a.lower() for a in (paper1.get('algorithms') or []))
        algo2 = set(a.lower() for a in (paper2.get('algorithms') or []))

        ds1 = set(d.lower() for d in (paper1.get('datasets') or []))
        ds2 = set(d.lower() for d in (paper2.get('datasets') or []))

        topics1 = set(paper1.get('topics') or [])
        topics2 = set(paper2.get('topics') or [])

        cit1 = set(paper1.get('citations') or [])
        cit2 = set(paper2.get('citations') or [])

        return {
            # ── Identifiers
            "paper1_title": paper1.get('title', 'Paper 1'),
            "paper2_title": paper2.get('title', 'Paper 2'),

            # ── Overall similarity score
            "overall_similarity": self._overall_similarity(
                kw1, kw2, algo1, algo2, ds1, ds2, topics1, topics2
            ),

            # ── Keyword comparison
            "keyword_overlap": sorted(kw1 & kw2),
            "keyword_only_p1": sorted(kw1 - kw2)[:10],
            "keyword_only_p2": sorted(kw2 - kw1)[:10],
            "keyword_similarity": self._jaccard(kw1, kw2),

            # ── Algorithm comparison
            "shared_algorithms": sorted(algo1 & algo2),
            "unique_algorithms_p1": sorted(algo1 - algo2),
            "unique_algorithms_p2": sorted(algo2 - algo1),

            # ── Dataset comparison
            "shared_datasets": sorted(ds1 & ds2),
            "unique_datasets_p1": sorted(ds1 - ds2),
            "unique_datasets_p2": sorted(ds2 - ds1),

            # ── Topic comparison
            "shared_topics": sorted(topics1 & topics2),
            "unique_topics_p1": sorted(topics1 - topics2),
            "unique_topics_p2": sorted(topics2 - topics1),
            "topic_similarity": self._jaccard(topics1, topics2),

            # ── Citation overlap
            "shared_citations_count": len(cit1 & cit2),
            "citation_overlap_pct": round(
                len(cit1 & cit2) / max(len(cit1 | cit2), 1) * 100, 1
            ),

            # ── Metadata comparison
            "stats_comparison": {
                "word_count":       [paper1.get('word_count', 0), paper2.get('word_count', 0)],
                "citation_count":   [paper1.get('citation_count', 0), paper2.get('citation_count', 0)],
                "complexity_score": [paper1.get('complexity_score', 0), paper2.get('complexity_score', 0)],
                "novelty_score":    [paper1.get('novelty_score', 0), paper2.get('novelty_score', 0)],
                "readability_score":[paper1.get('readability_score', 0), paper2.get('readability_score', 0)],
            },

            # ── Verdict
            "comparison_summary": self._generate_summary(paper1, paper2, kw1, kw2, algo1, algo2),
        }

    # ── Helpers ──────────────────────────────────────────────────

    def _kw_set(self, paper: dict) -> set:
        kws = paper.get('keywords') or []
        return set(
            k.get('word', str(k)).lower() if isinstance(k, dict) else str(k).lower()
            for k in kws
        )

    def _jaccard(self, a: set, b: set) -> float:
        """Jaccard similarity coefficient."""
        if not a and not b:
            return 0.0
        return round(len(a & b) / len(a | b) * 100, 1)

    def _overall_similarity(self, kw1, kw2, a1, a2, d1, d2, t1, t2) -> float:
        """Weighted average similarity across dimensions."""
        weights = [0.35, 0.25, 0.20, 0.20]
        scores  = [
            self._jaccard(kw1, kw2),
            self._jaccard(a1, a2),
            self._jaccard(d1, d2),
            self._jaccard(t1, t2),
        ]
        return round(sum(w * s for w, s in zip(weights, scores)), 1)

    def _generate_summary(self, p1, p2, kw1, kw2, algo1, algo2) -> str:
        """Generate a human-readable comparison summary."""
        sim = self._jaccard(kw1, kw2)
        shared_algo = algo1 & algo2

        if sim > 60:
            relation = "highly similar"
        elif sim > 30:
            relation = "moderately related"
        else:
            relation = "distinct in focus"

        summary = (
            f"'{p1.get('title','Paper 1')[:50]}' and "
            f"'{p2.get('title','Paper 2')[:50]}' are {relation} "
            f"with {sim}% keyword overlap. "
        )

        if shared_algo:
            summary += f"Both papers use {', '.join(list(shared_algo)[:3])}. "

        c1, c2 = p1.get('complexity_score', 0), p2.get('complexity_score', 0)
        if c1 and c2:
            more_complex = p1.get('title','Paper 1')[:30] if c1 > c2 else p2.get('title','Paper 2')[:30]
            summary += f"'{more_complex}' is technically more complex (score {max(c1,c2)}/10)."

        return summary
