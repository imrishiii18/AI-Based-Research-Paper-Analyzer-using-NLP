"""
========================================================
diagram_analyzer.py — Figure & Diagram Analyzer
========================================================
Detects and describes figures, tables, and charts
from PDF documents.

Capabilities:
  - Extract figure captions from text
  - Detect table structures
  - Rasterize PDF pages to images
  - Describe figures using AI (Anthropic Vision API)
  - Generate text summaries of detected visuals

Usage:
    analyzer = DiagramAnalyzer()
    figures = analyzer.analyze_pdf(filepath)
    # Returns list of {caption, description, page, type}
========================================================
"""

import re
import os
from typing import Optional

# ── Optional imports ──────────────────────────────────────────────
try:
    import pdfplumber
    PLUMBER_OK = True
except ImportError:
    PLUMBER_OK = False

try:
    import fitz   # PyMuPDF
    PYMUPDF_OK = True
except ImportError:
    PYMUPDF_OK = False

try:
    import anthropic
    ANTHROPIC_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
    _client = anthropic.Anthropic(api_key=ANTHROPIC_KEY) if ANTHROPIC_KEY else None
    VISION_OK = _client is not None
except ImportError:
    VISION_OK = False
    _client = None

try:
    import base64
    from PIL import Image
    import io
    PIL_OK = True
except ImportError:
    PIL_OK = False


# ══════════════════════════════════════════════════════════════════
class DiagramAnalyzer:

    # Figure caption regex patterns
    FIGURE_PATTERNS = [
        re.compile(r'(?:Figure|Fig\.?|FIGURE)\s*(\d+)[.:]\s*([^\n]{10,200})', re.I),
        re.compile(r'(?:Chart|Graph|Plot|Diagram)\s*(\d+)[.:]\s*([^\n]{10,200})', re.I),
    ]
    TABLE_PATTERNS = [
        re.compile(r'(?:Table|TABLE)\s*(\d+)[.:]\s*([^\n]{5,200})', re.I),
    ]

    def analyze_text(self, text: str) -> list:
        """
        Extract figure and table captions from plain text.
        Returns list of detected visuals with type and caption.
        """
        visuals = []

        for pat in self.FIGURE_PATTERNS:
            for m in pat.finditer(text):
                visuals.append({
                    "type":        "Figure",
                    "number":      m.group(1),
                    "caption":     m.group(2).strip(),
                    "description": self._infer_description(m.group(2).strip()),
                    "page":        None,
                    "has_image":   False,
                })

        for pat in self.TABLE_PATTERNS:
            for m in pat.finditer(text):
                visuals.append({
                    "type":        "Table",
                    "number":      m.group(1),
                    "caption":     m.group(2).strip(),
                    "description": self._infer_table_description(m.group(2).strip()),
                    "page":        None,
                    "has_image":   False,
                })

        # Deduplicate by caption
        seen = set()
        unique = []
        for v in visuals:
            key = v['caption'][:40]
            if key not in seen:
                seen.add(key)
                unique.append(v)

        return unique[:20]

    def analyze_pdf(self, filepath: str) -> list:
        """
        Full PDF analysis — extract text-based captions,
        attempt image extraction and AI description.
        """
        if not os.path.exists(filepath):
            return []

        visuals = []

        # Step 1: Text-based caption extraction
        if PLUMBER_OK:
            try:
                with pdfplumber.open(filepath) as pdf:
                    full_text = '\n'.join(
                        p.extract_text() or '' for p in pdf.pages
                    )
                    visuals.extend(self.analyze_text(full_text))
            except Exception as e:
                print(f"[DiagramAnalyzer] pdfplumber error: {e}")

        # Step 2: Image extraction from PDF pages
        if PYMUPDF_OK and PIL_OK:
            visuals = self._enrich_with_images(filepath, visuals)

        return visuals

    def _enrich_with_images(self, filepath: str, visuals: list) -> list:
        """
        Render each PDF page, extract embedded images,
        and use AI vision to describe them (if available).
        """
        try:
            doc = fitz.open(filepath)
        except Exception:
            return visuals

        image_count = 0
        for page_num, page in enumerate(doc):
            # Get embedded images on this page
            img_list = page.get_images(full=True)
            for img_index, img_info in enumerate(img_list[:3]):  # Max 3 per page
                try:
                    xref = img_info[0]
                    base_image = doc.extract_image(xref)
                    img_bytes = base_image["image"]
                    img_ext   = base_image["ext"]

                    # Describe with AI vision if available
                    description = ""
                    if VISION_OK:
                        description = self._describe_image_ai(img_bytes, img_ext)

                    # Match to an existing caption if possible
                    if image_count < len(visuals):
                        visuals[image_count]['has_image'] = True
                        visuals[image_count]['page'] = page_num + 1
                        if description:
                            visuals[image_count]['description'] = description
                    else:
                        # New figure not mentioned in text
                        visuals.append({
                            "type":        "Figure",
                            "number":      str(image_count + 1),
                            "caption":     f"Embedded image on page {page_num + 1}",
                            "description": description or "Visual element detected in paper.",
                            "page":        page_num + 1,
                            "has_image":   True,
                        })

                    image_count += 1
                    if image_count >= 10:
                        break
                except Exception:
                    continue

        doc.close()
        return visuals

    def _describe_image_ai(self, img_bytes: bytes, img_ext: str) -> str:
        """
        Use Anthropic's vision capability to describe a figure image.
        Returns a text description.
        """
        if not VISION_OK or not _client:
            return ""

        try:
            import base64 as b64_module

            # Map extension to MIME type
            mime_map = {
                'jpeg': 'image/jpeg', 'jpg': 'image/jpeg',
                'png': 'image/png', 'gif': 'image/gif',
                'webp': 'image/webp'
            }
            media_type = mime_map.get(img_ext.lower(), 'image/png')
            image_data = b64_module.b64encode(img_bytes).decode('utf-8')

            message = _client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=300,
                messages=[{
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": image_data,
                            },
                        },
                        {
                            "type": "text",
                            "text": (
                                "This is a figure from a research paper. "
                                "In 2-3 sentences, describe: what type of visual this is "
                                "(chart, diagram, graph, architecture diagram, etc.), "
                                "what it appears to show, and what insight it conveys. "
                                "Be specific and technical."
                            )
                        }
                    ],
                }]
            )
            return message.content[0].text.strip()

        except Exception as e:
            print(f"[DiagramAnalyzer] Vision API error: {e}")
            return ""

    def _infer_description(self, caption: str) -> str:
        """Generate a heuristic description based on caption keywords."""
        caption_lower = caption.lower()
        if any(k in caption_lower for k in ['architecture', 'network', 'model', 'structure']):
            return f"Architecture or structural diagram showing {caption}. Likely illustrates the proposed model components and their relationships."
        elif any(k in caption_lower for k in ['result', 'performance', 'accuracy', 'comparison']):
            return f"Results chart comparing {caption}. Shows quantitative performance metrics across different methods or configurations."
        elif any(k in caption_lower for k in ['loss', 'training', 'curve', 'epoch']):
            return f"Training progress visualization for {caption}. Displays learning dynamics over training iterations."
        elif any(k in caption_lower for k in ['flow', 'pipeline', 'process', 'workflow']):
            return f"Flowchart or pipeline diagram for {caption}. Illustrates the step-by-step process or workflow."
        elif any(k in caption_lower for k in ['distribution', 'histogram', 'frequency']):
            return f"Statistical distribution plot for {caption}. Shows data distribution or frequency analysis."
        else:
            return f"Visual element depicting: {caption}. Provides supplementary illustration for the research findings."

    def _infer_table_description(self, caption: str) -> str:
        """Generate heuristic description for a table."""
        cap = caption.lower()
        if any(k in cap for k in ['result', 'performance', 'accuracy', 'comparison', 'benchmark']):
            return f"Results table comparing {caption}. Contains quantitative performance metrics enabling direct comparison between methods."
        elif any(k in cap for k in ['dataset', 'statistic', 'distribution']):
            return f"Dataset statistics table for {caption}. Summarizes characteristics of the data used in experiments."
        elif any(k in cap for k in ['hyperparameter', 'parameter', 'setting', 'configuration']):
            return f"Configuration table for {caption}. Lists model hyperparameters and experimental settings."
        else:
            return f"Tabular data for: {caption}. Organizes structured information for reference."
