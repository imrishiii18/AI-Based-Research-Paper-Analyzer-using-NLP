# backend/models/__init__.py
# Package for storing local ML models or model configs
