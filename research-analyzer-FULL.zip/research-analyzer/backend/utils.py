"""
========================================================
utils.py — Shared Utility Functions
========================================================
Helper functions used across the backend:
  - Text cleaning & normalization
  - File validation
  - Response formatting
  - Logging helpers
  - Timer/benchmark decorator
  - Language detection
  - Text chunking for large papers
========================================================
"""

import re
import os
import time
import json
import logging
import hashlib
import unicodedata
from functools import wraps
from datetime import datetime
from typing import Any, Optional

# ── Logger Setup ──────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s — %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger("ResearchAnalyzer")


# ══════════════════════════════════════════════════════════════════
# TEXT UTILITIES
# ══════════════════════════════════════════════════════════════════

def clean_text(text: str) -> str:
    """
    Normalize and clean raw extracted text.
    - Remove excessive whitespace
    - Fix encoding artifacts
    - Normalize Unicode
    - Remove non-printable characters
    """
    # Normalize unicode (handle ligatures, special chars)
    text = unicodedata.normalize('NFKD', text)

    # Remove non-printable characters (keep newlines and tabs)
    text = ''.join(ch for ch in text if unicodedata.category(ch)[0] != 'C' or ch in '\n\t ')

    # Fix common PDF extraction artifacts
    text = re.sub(r'(\w)-\n(\w)', r'\1\2', text)        # Fix hyphenation
    text = re.sub(r'\n{3,}', '\n\n', text)               # Collapse blank lines
    text = re.sub(r'[ \t]{2,}', ' ', text)               # Collapse spaces
    text = re.sub(r'^\s+', '', text, flags=re.MULTILINE) # Strip line-leading spaces

    # Remove page numbers (common patterns)
    text = re.sub(r'\n\s*\d+\s*\n', '\n', text)

    # Remove repeated header/footer lines (heuristic: short repeated lines)
    lines = text.split('\n')
    line_counts = {}
    for l in lines:
        stripped = l.strip()
        if stripped:
            line_counts[stripped] = line_counts.get(stripped, 0) + 1
    # Remove lines that appear more than 3 times (likely headers/footers)
    cleaned_lines = [
        l for l in lines
        if not l.strip() or line_counts.get(l.strip(), 0) <= 3
    ]
    return '\n'.join(cleaned_lines).strip()


def truncate_text(text: str, max_chars: int = 50000) -> str:
    """Safely truncate text to max_chars, respecting sentence boundaries."""
    if len(text) <= max_chars:
        return text
    truncated = text[:max_chars]
    # Try to end at a sentence boundary
    last_period = max(
        truncated.rfind('. '),
        truncated.rfind('.\n'),
        truncated.rfind('! '),
        truncated.rfind('? ')
    )
    if last_period > max_chars * 0.8:
        return truncated[:last_period + 1]
    return truncated


def chunk_text(text: str, chunk_size: int = 3000, overlap: int = 200) -> list:
    """
    Split long text into overlapping chunks for processing.
    Useful for large papers that exceed API context limits.
    """
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start += chunk_size - overlap
    return chunks


def count_words(text: str) -> int:
    """Count words in text."""
    return len(re.findall(r'\b\w+\b', text))


def count_sentences(text: str) -> int:
    """Approximate sentence count."""
    return len(re.findall(r'[.!?]+', text))


def count_paragraphs(text: str) -> int:
    """Count paragraphs (blank-line separated)."""
    return len([p for p in text.split('\n\n') if p.strip()])


def extract_abstract(text: str) -> str:
    """Extract abstract section from paper text."""
    patterns = [
        r'(?:abstract|summary)\s*\n+(.*?)(?:\n\n|\d+\.\s+introduction)',
        r'ABSTRACT\s+(.*?)(?:Keywords|Introduction|1\.)',
        r'Abstract[-—–]\s*(.*?)(?:\n\n|Keywords)',
    ]
    for pat in patterns:
        m = re.search(pat, text, re.I | re.DOTALL)
        if m:
            abstract = m.group(1).strip()
            if 50 < len(abstract) < 3000:
                return abstract
    # Fallback: first 3 paragraphs
    paragraphs = [p.strip() for p in text.split('\n\n') if len(p.strip()) > 100]
    return ' '.join(paragraphs[:2])[:1500]


def extract_keywords_section(text: str) -> list:
    """Extract explicitly stated keywords from paper."""
    patterns = [
        r'[Kk]eywords?\s*[:—–]\s*(.*?)(?:\n\n|\n[A-Z])',
        r'[Kk]ey [Ww]ords?\s*[:—–]\s*(.*?)(?:\n\n)',
        r'INDEX TERMS\s*[:—–]\s*(.*?)(?:\n\n)',
    ]
    for pat in patterns:
        m = re.search(pat, text, re.DOTALL)
        if m:
            kw_text = m.group(1).strip()
            kws = re.split(r'[,;·•]', kw_text)
            kws = [k.strip() for k in kws if 2 < len(k.strip()) < 50]
            if kws:
                return kws[:12]
    return []


# ══════════════════════════════════════════════════════════════════
# FILE UTILITIES
# ══════════════════════════════════════════════════════════════════

def allowed_file(filename: str, allowed_extensions: set) -> bool:
    """Check if file extension is allowed."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in allowed_extensions


def get_file_size_kb(filepath: str) -> float:
    """Return file size in KB."""
    return os.path.getsize(filepath) / 1024


def file_hash(filepath: str) -> str:
    """Compute MD5 hash of a file (for deduplication)."""
    h = hashlib.md5()
    with open(filepath, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()


def safe_delete(filepath: str) -> bool:
    """Safely delete a file without raising exceptions."""
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
            return True
    except Exception as e:
        logger.warning(f"Could not delete {filepath}: {e}")
    return False


# ══════════════════════════════════════════════════════════════════
# RESPONSE UTILITIES
# ══════════════════════════════════════════════════════════════════

def success_response(data: dict, message: str = "Success") -> dict:
    """Standard success JSON response wrapper."""
    return {
        "status": "success",
        "message": message,
        "timestamp": datetime.utcnow().isoformat(),
        "data": data
    }


def error_response(message: str, code: int = 400) -> tuple:
    """Standard error JSON response."""
    return {
        "status": "error",
        "message": message,
        "timestamp": datetime.utcnow().isoformat()
    }, code


def sanitize_output(obj: Any) -> Any:
    """
    Recursively sanitize output for JSON serialization.
    Converts non-serializable types to strings.
    """
    if isinstance(obj, dict):
        return {k: sanitize_output(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [sanitize_output(i) for i in obj]
    elif isinstance(obj, (int, float, bool, type(None))):
        return obj
    else:
        return str(obj)


# ══════════════════════════════════════════════════════════════════
# LANGUAGE DETECTION (lightweight)
# ══════════════════════════════════════════════════════════════════

# Common words in various languages for simple detection
LANG_INDICATORS = {
    "English":  ["the", "and", "of", "to", "a", "in", "is", "that", "for", "it"],
    "Spanish":  ["el", "la", "los", "en", "que", "de", "por", "con", "una", "para"],
    "French":   ["le", "la", "les", "de", "et", "en", "que", "pour", "un", "une"],
    "German":   ["die", "der", "und", "in", "den", "von", "mit", "das", "ist", "sich"],
    "Hindi":    ["और", "है", "में", "की", "के", "एक", "से", "को", "पर", "था"],
    "Chinese":  ["的", "了", "在", "是", "我", "有", "他", "这", "为", "之"],
}


def detect_language(text: str) -> str:
    """
    Simple language detection based on common word frequency.
    Returns language name (e.g., 'English', 'French').
    """
    sample = text[:2000].lower()
    words = re.findall(r'\b\w+\b', sample)
    word_set = set(words)

    scores = {}
    for lang, indicators in LANG_INDICATORS.items():
        scores[lang] = sum(1 for w in indicators if w in word_set)

    if not scores:
        return "Unknown"
    best_lang = max(scores, key=scores.get)
    return best_lang if scores[best_lang] > 2 else "English"


# ══════════════════════════════════════════════════════════════════
# DECORATORS
# ══════════════════════════════════════════════════════════════════

def timer(func):
    """Decorator to log execution time of a function."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        logger.info(f"⏱  {func.__name__} completed in {elapsed:.2f}s")
        return result
    return wrapper


def catch_errors(default_return=None):
    """Decorator to catch and log exceptions, returning a default value."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"❌ Error in {func.__name__}: {e}")
                return default_return
        return wrapper
    return decorator


# ══════════════════════════════════════════════════════════════════
# FORMATTING HELPERS
# ══════════════════════════════════════════════════════════════════

def format_number(n: int) -> str:
    """Format large numbers with commas: 12345 → '12,345'"""
    return f"{n:,}"


def truncate_string(s: str, max_len: int = 100, ellipsis: str = "...") -> str:
    """Truncate a string with ellipsis if too long."""
    return s if len(s) <= max_len else s[:max_len - len(ellipsis)] + ellipsis


def snake_to_title(s: str) -> str:
    """Convert snake_case to Title Case: 'key_findings' → 'Key Findings'"""
    return s.replace('_', ' ').title()


def duration_human(seconds: float) -> str:
    """Convert seconds to human-readable: 75.4 → '1m 15s'"""
    m, s = divmod(int(seconds), 60)
    return f"{m}m {s}s" if m else f"{s}s"
