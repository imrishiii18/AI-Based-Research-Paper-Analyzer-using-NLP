"""
========================================================
wordcloud_gen.py — Word Cloud Generator
========================================================
Generates a styled word cloud image from paper keywords.
Saves as PNG and returns base64 for embedding in frontend.

Endpoint: POST /api/wordcloud
Body:    { "text": "...", "keywords": [...] }
Returns: { "image_b64": "data:image/png;base64,..." }
========================================================
"""

import io
import re
import base64
import os
from collections import Counter
from typing import Optional

# ── Optional imports (graceful fallback) ─────────────────────────
try:
    from wordcloud import WordCloud, STOPWORDS
    WC_OK = True
except ImportError:
    WC_OK = False
    print("[WARN] wordcloud not installed: pip install wordcloud")

try:
    import matplotlib
    matplotlib.use('Agg')   # Non-interactive backend
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors
    MPL_OK = True
except ImportError:
    MPL_OK = False
    print("[WARN] matplotlib not installed: pip install matplotlib")

try:
    from PIL import Image
    PIL_OK = True
except ImportError:
    PIL_OK = False

import nltk
try:
    from nltk.corpus import stopwords
    STOPWORDS_SET = set(stopwords.words('english'))
except Exception:
    STOPWORDS_SET = set()


# ── Color Themes ─────────────────────────────────────────────────
COLOR_THEMES = {
    "indigo": ["#6366f1", "#818cf8", "#4f46e5", "#8b5cf6", "#7c3aed", "#22d3ee", "#06b6d4"],
    "ocean":  ["#0284c7", "#0ea5e9", "#38bdf8", "#7dd3fc", "#22d3ee", "#2dd4bf"],
    "forest": ["#059669", "#10b981", "#34d399", "#6ee7b7", "#a7f3d0", "#065f46"],
    "sunset": ["#f59e0b", "#f97316", "#ef4444", "#ec4899", "#d946ef", "#8b5cf6"],
    "mono":   ["#e2e8f0", "#cbd5e1", "#94a3b8", "#64748b", "#475569", "#334155"],
}


# ══════════════════════════════════════════════════════════════════
def generate_wordcloud(
    text: str,
    keywords: Optional[list] = None,
    theme: str = "indigo",
    width: int = 900,
    height: int = 500,
    max_words: int = 80,
    background: str = "transparent"
) -> Optional[str]:
    """
    Generate a word cloud image from text or pre-extracted keywords.

    Args:
        text:       Raw paper text (used if keywords not provided)
        keywords:   List of {"word": str, "freq": int} dicts
        theme:      Color theme name from COLOR_THEMES
        width/height: Image dimensions in pixels
        max_words:  Maximum words in cloud
        background: Background color ('transparent' or hex)

    Returns:
        Base64-encoded PNG string (data:image/png;base64,...) or None on failure
    """
    if not WC_OK or not MPL_OK:
        return _generate_fallback_svg(keywords or [], theme)

    # ── Build frequency dict ──────────────────────────────────
    if keywords:
        freq_dict = {
            k.get('word', str(k)): max(1, k.get('freq', 10))
            for k in keywords if k.get('word')
        }
    else:
        # Tokenize text and count word frequencies
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
        stop = STOPWORDS_SET | STOPWORDS | {
            'paper', 'study', 'research', 'result', 'show', 'method',
            'also', 'using', 'used', 'based', 'proposed', 'data', 'model'
        }
        words = [w for w in words if w not in stop]
        freq_dict = dict(Counter(words).most_common(max_words))

    if not freq_dict:
        return None

    # ── Color function ────────────────────────────────────────
    colors = COLOR_THEMES.get(theme, COLOR_THEMES["indigo"])
    color_cycle = iter(colors * (max_words // len(colors) + 1))

    def color_func(word, font_size, position, orientation, random_state=None, **kwargs):
        return next(color_cycle)

    # ── Generate cloud ────────────────────────────────────────
    wc = WordCloud(
        width=width,
        height=height,
        max_words=max_words,
        background_color=None if background == "transparent" else background,
        mode="RGBA" if background == "transparent" else "RGB",
        prefer_horizontal=0.75,
        min_font_size=10,
        max_font_size=100,
        color_func=color_func,
        collocations=False,
        margin=10,
    ).generate_from_frequencies(freq_dict)

    # ── Render to PNG buffer ──────────────────────────────────
    fig, ax = plt.subplots(figsize=(width/100, height/100), dpi=100)
    ax.imshow(wc, interpolation='bilinear')
    ax.axis('off')
    fig.patch.set_alpha(0)
    ax.set_facecolor('none')
    plt.tight_layout(pad=0)

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight',
                transparent=(background == "transparent"),
                facecolor='none' if background == "transparent" else 'white')
    plt.close(fig)
    buf.seek(0)

    b64 = base64.b64encode(buf.read()).decode('utf-8')
    return f"data:image/png;base64,{b64}"


def generate_keyword_barchart(keywords: list, theme: str = "indigo") -> Optional[str]:
    """
    Generate a horizontal bar chart of top keywords.
    Returns base64 PNG string.
    """
    if not MPL_OK or not keywords:
        return None

    colors = COLOR_THEMES.get(theme, COLOR_THEMES["indigo"])
    top = keywords[:15]
    words = [k.get('word', str(k)) for k in top]
    freqs = [k.get('freq', 1) for k in top]

    fig, ax = plt.subplots(figsize=(10, 6), dpi=100)
    fig.patch.set_facecolor('#0d1224')
    ax.set_facecolor('#090d1a')

    bar_colors = [colors[i % len(colors)] for i in range(len(words))]
    bars = ax.barh(words, freqs, color=bar_colors, edgecolor='none', height=0.65)

    ax.tick_params(colors='#94a3b8', labelsize=10)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#1e293b')
    ax.spines['bottom'].set_color('#1e293b')
    ax.xaxis.label.set_color('#94a3b8')
    ax.set_xlabel('Frequency', color='#94a3b8', fontsize=11)
    ax.set_title('Top Keywords', color='#f0f2ff', fontsize=14, pad=14)

    # Value labels on bars
    for bar, freq in zip(bars, freqs):
        ax.text(
            bar.get_width() + 0.3, bar.get_y() + bar.get_height() / 2,
            str(freq), va='center', color='#94a3b8', fontsize=9
        )

    plt.tight_layout()
    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight',
                facecolor='#0d1224', edgecolor='none')
    plt.close(fig)
    buf.seek(0)

    b64 = base64.b64encode(buf.read()).decode('utf-8')
    return f"data:image/png;base64,{b64}"


def generate_sentiment_pie(sentiment_scores: dict) -> Optional[str]:
    """Generate a styled pie chart for sentiment scores. Returns base64 PNG."""
    if not MPL_OK:
        return None

    labels = list(sentiment_scores.keys())
    sizes  = list(sentiment_scores.values())
    colors = ['#6366f1', '#10b981', '#94a3b8']

    fig, ax = plt.subplots(figsize=(5, 5), dpi=100)
    fig.patch.set_facecolor('#0d1224')
    ax.set_facecolor('#0d1224')

    wedges, texts, autotexts = ax.pie(
        sizes, labels=labels, colors=colors,
        autopct='%1.0f%%', startangle=140,
        pctdistance=0.75,
        wedgeprops=dict(edgecolor='#0d1224', linewidth=2)
    )
    for text in texts:
        text.set_color('#94a3b8')
    for at in autotexts:
        at.set_color('#f0f2ff')
        at.set_fontsize(11)

    ax.set_title('Writing Tone', color='#f0f2ff', fontsize=13, pad=10)
    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight',
                facecolor='#0d1224', edgecolor='none')
    plt.close(fig)
    buf.seek(0)

    b64 = base64.b64encode(buf.read()).decode('utf-8')
    return f"data:image/png;base64,{b64}"


def _generate_fallback_svg(keywords: list, theme: str = "indigo") -> str:
    """
    Generate a simple SVG word cloud fallback when wordcloud/matplotlib
    are not installed.
    """
    colors = COLOR_THEMES.get(theme, COLOR_THEMES["indigo"])
    words = keywords[:20] if keywords else []

    import random
    items = []
    for i, kw in enumerate(words):
        word = kw.get('word', str(kw)) if isinstance(kw, dict) else str(kw)
        freq = kw.get('freq', 10) if isinstance(kw, dict) else 10
        size = max(12, min(40, int(freq * 0.8 + 10)))
        x = 50 + (i % 5) * 150 + random.randint(-20, 20)
        y = 80 + (i // 5) * 90 + random.randint(-15, 15)
        color = colors[i % len(colors)]
        items.append(
            f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" '
            f'font-family="Space Grotesk, sans-serif" font-weight="600">{word}</text>'
        )

    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 400"
         style="background:transparent">
  {''.join(items)}
</svg>'''

    b64 = base64.b64encode(svg.encode()).decode()
    return f"data:image/svg+xml;base64,{b64}"
