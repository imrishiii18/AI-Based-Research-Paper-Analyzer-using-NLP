"""
========================================================
config.py — Centralized Configuration
========================================================
All app settings, paths, and constants in one place.
Edit this file to customize the analyzer behavior.
========================================================
"""

import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# ── API Keys ──────────────────────────────────────────────────────
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

# ── Flask Settings ────────────────────────────────────────────────
class FlaskConfig:
    SECRET_KEY         = os.getenv("SECRET_KEY", "research-analyzer-secret-2024")
    DEBUG              = os.getenv("FLASK_DEBUG", "True") == "True"
    HOST               = os.getenv("FLASK_HOST", "0.0.0.0")
    PORT               = int(os.getenv("FLASK_PORT", 5000))
    MAX_CONTENT_LENGTH = 32 * 1024 * 1024   # 32 MB max upload
    UPLOAD_FOLDER      = os.path.join(os.path.dirname(__file__), "uploads")
    REPORT_FOLDER      = os.path.join(os.path.dirname(__file__), "reports")
    ALLOWED_EXTENSIONS = {"pdf", "docx", "txt"}

# ── NLP Settings ──────────────────────────────────────────────────
class NLPConfig:
    SPACY_MODEL          = "en_core_web_sm"   # or en_core_web_md / en_core_web_lg
    MAX_TEXT_LENGTH      = 50_000             # Characters to process (truncate beyond this)
    SUMMARY_SENTENCES    = 5                  # Number of sentences in extractive summary
    MAX_KEYWORDS         = 20                 # Top N keywords to extract
    MAX_CITATIONS        = 60                 # Max citations to extract
    MAX_SECTIONS         = 12                 # Max paper sections to detect
    MIN_TEXT_LENGTH      = 80                 # Minimum chars required for analysis
    CHAT_CONTEXT_CHARS   = 6_000             # Paper text chars sent to AI for chat

# ── AI Model Settings ─────────────────────────────────────────────
class AIConfig:
    CLAUDE_MODEL         = "claude-sonnet-4-20250514"
    MAX_TOKENS_ANALYSIS  = 2000
    MAX_TOKENS_CHAT      = 600
    MAX_TOKENS_SUMMARY   = 1500
    ANALYSIS_TEXT_LIMIT  = 8_000     # Chars sent to Claude for analysis

# ── Report Settings ───────────────────────────────────────────────
class ReportConfig:
    PAGE_SIZE          = "A4"
    FONT_TITLE         = "Helvetica-Bold"
    FONT_BODY          = "Helvetica"
    PRIMARY_COLOR      = "#6366f1"   # Indigo
    SECONDARY_COLOR    = "#8b5cf6"   # Violet
    MAX_CITATIONS_PDF  = 40
    MAX_FINDINGS_PDF   = 8
    LOGO_TEXT          = "🔬 AI Research Paper Analyzer"

# ── Algorithm Patterns (for detection) ───────────────────────────
ALGORITHM_PATTERNS = [
    r'\b(BERT|GPT(?:-\d+)?|T5|RoBERTa|XLNet|DistilBERT|ALBERT|ELECTRA|DeBERTa)\b',
    r'\b(CNN|RNN|LSTM|GRU|GAN|VAE|Transformer|Attention|Diffusion)\b',
    r'\b(SVM|Random Forest|Decision Tree|KNN|Naive Bayes|Logistic Regression|XGBoost)\b',
    r'\b(K-means|DBSCAN|PCA|t-SNE|UMAP|Word2Vec|GloVe|FastText)\b',
    r'\b(ResNet|VGG|YOLO|EfficientNet|MobileNet|InceptionNet|ViT)\b',
    r'\b(Adam|SGD|AdaGrad|RMSprop|LAMB|AdamW)\b',
    r'\b(TF-IDF|TextRank|RAKE|LDA|LSA|NMF|BM25)\b',
    r'\b(reinforcement learning|transfer learning|federated learning|meta-learning|contrastive learning)\b',
    r'\b(backpropagation|gradient descent|cross-entropy|softmax|sigmoid|attention mechanism)\b',
    r'\b(LoRA|QLoRA|PEFT|Prompt Tuning|Instruction Tuning|RLHF)\b',
    r'\b(Flash Attention|Rotary Embeddings|ALiBi|Sparse Attention|Mixture of Experts)\b',
]

# ── Dataset Patterns ──────────────────────────────────────────────
DATASET_PATTERNS = [
    r'\b(ImageNet|COCO|CIFAR-(?:10|100)|MNIST|Fashion-MNIST|STL-10)\b',
    r'\b(GLUE|SuperGLUE|SQuAD(?:\s+2\.0)?|CoNLL-\d+|WMT-\d+|SNLI|MultiNLI)\b',
    r'\b(UCI|Kaggle|IMDB|SST-[12]|20 ?Newsgroups|Reuters|AG News)\b',
    r'\b(MS[-\s]?COCO|Open Images|LAION|Common Crawl|The Pile|C4|RedPajama)\b',
    r'\b(Penn Treebank|Wikipedia|BookCorpus|OpenWebText|Pile of Law)\b',
    r'\b(HumanEval|MBPP|BigBench|MMLU|HellaSwag|ARC|TruthfulQA)\b',
]

# ── Ensure directories exist ──────────────────────────────────────
os.makedirs(FlaskConfig.UPLOAD_FOLDER, exist_ok=True)
os.makedirs(FlaskConfig.REPORT_FOLDER, exist_ok=True)
